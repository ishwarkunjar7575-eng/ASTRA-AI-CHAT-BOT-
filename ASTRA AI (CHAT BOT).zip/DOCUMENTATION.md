# ASTRA AI — Comprehensive System Documentation & Technical Manual

**Product Version:** 2.0.0  
**Engine:** Google GenAI TypeScript SDK (`@google/genai`)  
**Deployment Platform:** Full-Stack Node.js (Cloud Run / Vite SPA)  

---

## 1. Executive Summary

**ASTRA AI** is a next-generation multimodal artificial intelligence workbench and conversational assistant. It unifies advanced language reasoning, real-time bidirectional live voice streaming, authoritative biomedical and scientific exploration, Google Search and Maps grounding, and text-to-image synthesis into a unified interface.

---

## 2. System Architecture

```
                          ┌───────────────────────────┐
                          │    Browser Client (SPA)   │
                          │   React 19 + Tailwind CSS │
                          └─────────────┬─────────────┘
                                        │
                         HTTP SSE / WebSocket (/api/live)
                                        │
                          ┌─────────────▼─────────────┐
                          │   Express Full-Stack Host │
                          │   Node.js 22 + TypeScript │
                          └─────────────┬─────────────┘
                                        │
           ┌────────────────────────────┼────────────────────────────┐
           │                            │                            │
 ┌─────────▼─────────┐        ┌─────────▼─────────┐        ┌─────────▼─────────┐
 │   Google GenAI    │        │  Firebase Cloud   │        │ Scientific REST   │
 │   Gemini SDK      │        │  Auth + Firestore │        │ PubChem, UniProt, │
 │                   │        │                   │        │ AlphaFold, PubMed │
 └───────────────────┘        └───────────────────┘        └───────────────────┘
```

### Key Architectural Pillars:
1. **Server-Side API Proxying**: API keys are securely guarded on the server (`process.env.GEMINI_API_KEY`). No client-side keys are exposed.
2. **Resilient Token Streaming**: Server-Sent Events (SSE) with `X-Accel-Buffering: no` and automatic high-demand failover (`gemini-3.8-flash` → `gemini-3.1-flash-lite`).
3. **Bi-Directional Live Audio**: Express WebSocket server bridge to `gemini-3.8-live` supporting 16kHz PCM input and 24kHz audio playback.
4. **Zero-Trust Firebase ABAC Rules**: Attribute-based access control protecting user sessions and message threads in Cloud Firestore.

---

## 3. Model Suite & Intelligent Engines

ASTRA AI offers multi-model switching tailored to task complexity:

| Model ID | Engine Name | Intelligence | Speed | Key Capabilities |
| :--- | :--- | :--- | :--- | :--- |
| `gemini-3.8-flash` | **ASTRA AI 3.8 Flash** | High | Ultra-Fast | Multimodal reasoning, code, balanced dialogue (Default) |
| `gemini-3.5-flash` | **ASTRA AI 3.5 Flash** | High | Fast | Grounded in Google Search & Google Maps data |
| `gemini-3.1-pro-preview` | **ASTRA AI 3.1 Pro** | Flagship | Standard | Complex reasoning, STEM proofs, software architecture |
| `gemini-3.1-flash-lite` | **ASTRA AI Lite** | Standard | Instant | Sub-second latency for summaries and quick facts |
| `gemini-3.8-live` | **ASTRA AI Live** | High | Real-time | Bidirectional conversational speech & audio |
| `gemini-3.8-flash-lite-tts` | **Neural TTS** | HD Audio | Instant | Studio-quality 24kHz neural speech generation |
| `gemini-nano-banana-2.1` | **Image Studio** | Multimodal | Fast | Text-to-image creation and image editing |

---

## 4. Specialized Personas

ASTRA AI includes calibrated system instruction modes:
1. **Balanced Assistant**: Nuanced, structured answers with tables and markdown.
2. **Software Architect**: Production-ready code, edge cases, and design patterns.
3. **Biomedical & Science Scout**: Strict DeepMind Science accuracy, citing accession IDs, pLDDT metrics, and PubMed PMIDs.
4. **Creative Thinker**: Lateral brainstorming, narrative depth, and metaphorical thinking.
5. **Concise & Direct**: High-density bullet points without conversational pleasantries.
6. **Socratic Tutor**: Step-by-step conceptual breakdowns and intuitive everyday analogies.

---

## 5. Grounding Capabilities

- **Google Search Grounding**: Connects ASTRA AI directly to the live Google web search index to provide up-to-the-minute information and citations.
- **Google Maps Grounding**: Queries geospatial locations, restaurants, venues, directions, and reviews via Google Maps.

---

## 6. Voice Assistant & Real-Time Audio

- **Real-Time Live Call (`gemini-3.8-live`)**:
  - Web Audio API capturing 16kHz PCM audio via ScriptProcessor.
  - Express WebSocket bridge forwarding raw audio to Gemini Live API.
  - 24kHz audio synthesis played back via AudioContext.
  - Live conversation transcript box.
  - Active interruption handling (user speech stops AI playback).
- **Neural Text-to-Speech (`gemini-3.8-flash-lite-tts`)**:
  - Read Aloud on all assistant responses in 5 voice options:
    - **Natural** (Warm, balanced, conversational)
    - **Kore** (Articulate, crisp, professional)
    - **Puck** (Energetic, cheerful, bright)
    - **Fenrir** (Deep, resonant, confident)
    - **Charon** (Calm, thoughtful, serene)
  - Auto-Read mode to speak generated answers out loud automatically.

---

## 7. DeepMind Science Skills & Research Workbench

Integrated authoritative scientific APIs:
- **PubChem**: Chemical structure lookup, molecular formula, weight, IUPAC name, canonical SMILES, and 2D chemical structure diagrams.
- **UniProtKB**: Protein sequence database queries, organism taxonomy, and sequence length.
- **AlphaFold DB**: 3D protein structure predictions, mmCIF/PDB coordinate downloads, and 4-tier pLDDT confidence scale (`>90` Very High, `70-90` Confident, `50-70` Low, `<50` Very Low).
- **PubMed**: Peer-reviewed biomedical literature citations and abstract queries via NCBI E-utilities.

---

## 8. Database & Persistence (Firebase)

- **Authentication**: Google Sign-In with popup.
- **Cloud Firestore**:
  - `/users/{userId}`: User profile documents.
  - `/users/{userId}/sessions/{sessionId}`: Conversation sessions.
  - `/users/{userId}/sessions/{sessionId}/messages/{messageId}`: Message threads.
- **Security Rules**: Enforced ownership (`request.auth.uid == userId`) and ID validation (`isValidId()`).
- **Offline Mirror**: Automatic sync with browser `localStorage`.

---

## 9. API Reference Summary

| Endpoint | Method | Payload / Params | Purpose |
| :--- | :--- | :--- | :--- |
| `/api/health` | `GET` | - | Server health check and API key readiness |
| `/api/chat/stream` | `POST` | `{ messages, model, grounding, systemInstruction }` | Server-Sent Events (SSE) chat stream |
| `/api/chat/generate-title` | `POST` | `{ prompt }` | Generates 2-5 word chat title |
| `/api/image/generate` | `POST` | `{ prompt, base64Image, aspectRatio }` | Image synthesis via gemini-nano-banana-2.1 |
| `/api/voice/speak` | `POST` | `{ text, voiceName }` | 24kHz WAV neural speech generation |
| `/api/science/pubchem` | `GET` | `?query={name\|CID}` | PubChem compound metadata & 2D diagram |
| `/api/science/uniprot` | `GET` | `?query={protein}` | UniProtKB sequence lookup |
| `/api/science/alphafold` | `GET` | `?accession={id}` | AlphaFold DB structural prediction |
| `/api/science/pubmed` | `GET` | `?query={term}` | NCBI PubMed citations |
| `/api/live` | `WS` | Audio / Text Frames | Gemini 3.8 Live API real-time audio |

---

## 10. Deployment Guidelines

1. **Build Process**:
   ```bash
   npm run build
   ```
2. **Production Startup**:
   ```bash
   npm start # executes node server.ts
   ```
3. **Environment Configuration**:
   ```env
   GEMINI_API_KEY=your_gemini_api_key
   PORT=3000
   ```
