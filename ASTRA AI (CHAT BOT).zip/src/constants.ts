import { ModelOption, Persona } from './types';

export const STORAGE_KEYS = {
  SESSIONS: 'astra_ai_sessions',
  CURRENT_SESSION_ID: 'astra_ai_current_session_id',
  THEME: 'astra_ai_theme',
  SELECTED_MODEL: 'astra_ai_selected_model',
  SELECTED_PERSONA: 'astra_ai_selected_persona',
  GROUNDING_MODE: 'astra_ai_grounding_mode',
  SELECTED_VOICE: 'astra_ai_selected_voice',
};

export const VOICE_OPTIONS = [
  {
    id: 'Zephyr',
    name: 'Natural',
    gender: 'Balanced',
    description: 'Warm, natural, and highly expressive conversational tone',
    previewPhrase: 'Hi! I am your conversational voice assistant on ASTRA AI.',
  },
  {
    id: 'Kore',
    name: 'Kore',
    gender: 'Feminine',
    description: 'Crisp, articulate, and professional presentation',
    previewPhrase: 'Hello, I am Kore. How can I assist your workflow today?',
  },
  {
    id: 'Puck',
    name: 'Puck',
    gender: 'Masculine',
    description: 'Energetic, cheerful, and dynamic delivery',
    previewPhrase: 'Hey there! Ready to explore ideas together? Let’s do it!',
  },
  {
    id: 'Fenrir',
    name: 'Fenrir',
    gender: 'Deep',
    description: 'Deep, resonant, confident, and grounded presence',
    previewPhrase: 'Greetings. I am Fenrir, standing by to analyze and explain.',
  },
  {
    id: 'Charon',
    name: 'Charon',
    gender: 'Calm',
    description: 'Calm, thoughtful, serene, and steady pacing',
    previewPhrase: 'Welcome. Take your time, and let’s explore your thoughts.',
  },
];

export const AVAILABLE_MODELS: ModelOption[] = [
  {
    id: 'gemini-3.8-flash',
    name: 'ASTRA AI 3.8 Flash',
    tag: 'Recommended',
    description: 'Balanced, fast, multimodal reasoning & deep knowledge',
    speed: 'Ultra Fast',
    intelligence: 'High',
  },
  {
    id: 'gemini-3.5-flash',
    name: 'ASTRA AI 3.5 Flash',
    tag: 'Search & Maps',
    description: 'Optimized for Google Search & Maps real-time grounding',
    speed: 'Fast',
    intelligence: 'High',
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'ASTRA AI 3.1 Pro',
    tag: 'Deep Reasoning',
    description: 'Advanced reasoning, complex coding, STEM & scientific tasks',
    speed: 'Standard',
    intelligence: 'Flagship',
  },
  {
    id: 'gemini-3.1-flash-lite',
    name: 'ASTRA AI Lite',
    tag: 'Instant',
    description: 'Instant response generation for quick queries & summaries',
    speed: 'Instant',
    intelligence: 'Standard',
  },
];

export const GROUNDING_OPTIONS = [
  {
    id: 'none',
    name: 'Direct Knowledge',
    description: 'Base model parameters without external web queries',
    icon: 'Brain',
  },
  {
    id: 'search',
    name: 'Google Search Data',
    description: 'Ground answers in up-to-date real-time Google Search results',
    icon: 'Globe',
  },
  {
    id: 'maps',
    name: 'Google Maps Data',
    description: 'Ground answers in real-world location & place data via Google Maps',
    icon: 'MapPin',
  },
];

export const AVAILABLE_PERSONAS: Persona[] = [
  {
    id: 'standard',
    name: 'Balanced Assistant',
    badge: 'General',
    icon: 'Sparkles',
    description: 'Helpful, nuanced, friendly, and comprehensive responses.',
    systemInstruction:
      'You are ASTRA AI, an intelligent, helpful, and nuanced AI assistant. Provide clear, well-structured, insightful, and truthful answers. Use Markdown formatting, tables, lists, and code blocks with syntax highlighting whenever appropriate. Keep a friendly, professional tone.',
  },
  {
    id: 'science',
    name: 'Biomedical & Science Scout',
    badge: 'Science',
    icon: 'Atom',
    description: 'Biological pathways, protein structures, PubChem chemistry, genetics, and PubMed citations.',
    systemInstruction:
      'You are ASTRA AI in Science & Biomedical Scout mode. You adhere to DeepMind Science standards. Provide precise scientific explanations referencing chemical structures, UniProt/PDB IDs, AlphaFold confidence (pLDDT), genetic mechanisms, and clinical literature. Distinguish between experimental evidence and computational predictions.',
  },
  {
    id: 'coder',
    name: 'Software Architect',
    badge: 'Coding',
    icon: 'Code2',
    description: 'Deep technical analysis, clean code, edge cases, and best practices.',
    systemInstruction:
      'You are ASTRA AI in Software Architect mode. You specialize in clean code, algorithmic efficiency, system design, and software engineering best practices. Always provide production-ready code with clear inline explanations, TypeScript/modern syntax, edge-case coverage, and architectural considerations.',
  },
  {
    id: 'creative',
    name: 'Creative Thinker',
    badge: 'Creative',
    icon: 'Palette',
    description: 'Imaginative writing, brainstorming, storytelling, and novel ideas.',
    systemInstruction:
      'You are ASTRA AI in Creative Thinker mode. Think expansively, offer vivid imagery, creative angles, metaphorical illustrations, and outside-the-box conceptual solutions.',
  },
  {
    id: 'concise',
    name: 'Concise & Direct',
    badge: 'Brief',
    icon: 'Zap',
    description: 'Direct bullet points, executive summaries, zero pleasantries or fluff.',
    systemInstruction:
      'You are ASTRA AI in Concise mode. Be direct, crisp, and to the point. Avoid filler phrases, conversational fluff, or redundant caveats. Use bullet points and high-density information delivery.',
  },
  {
    id: 'tutor',
    name: 'Socratic Tutor',
    badge: 'Learning',
    icon: 'GraduationCap',
    description: 'Step-by-step conceptual breakdowns with intuitive real-world analogies.',
    systemInstruction:
      'You are ASTRA AI in Socratic Tutor mode. Explain complex topics clearly from first principles. Use intuitive everyday analogies, break ideas down step-by-step, check for understanding, and provide practical examples.',
  },
];

export const STARTER_PROMPTS = [
  {
    icon: 'Globe',
    category: 'Google Search Data',
    title: 'Current Tech Breakthroughs',
    prompt: 'Search the web for the latest artificial intelligence model releases and breakthroughs in 2026 and summarize their key capabilities.',
  },
  {
    icon: 'MapPin',
    category: 'Google Maps Data',
    title: 'Top Cafes with WiFi in Tokyo',
    prompt: 'Using Google Maps data, recommend 4 highly rated laptop-friendly specialty coffee shops in Shibuya, Tokyo with exact areas and vibes.',
  },
  {
    icon: 'Atom',
    category: 'Science Skills',
    title: 'Analyze Aspirin on PubChem',
    prompt: 'Explain the mechanism of action, chemical formula, and molecular targets of Aspirin (Acetylsalicylic acid, CID 2244) using scientific databases.',
  },
  {
    icon: 'Code2',
    category: 'Software Architecture',
    title: 'Real-time WebSocket Manager',
    prompt: 'Design a resilient TypeScript client-side WebSocket manager with automatic reconnection, heartbeat pings, and exponential backoff.',
  },
];
