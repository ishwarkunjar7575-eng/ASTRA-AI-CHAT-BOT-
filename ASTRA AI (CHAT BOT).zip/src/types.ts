export interface ChatImage {
  mimeType: string;
  data: string; // Base64 data without prefix or with prefix
  previewUrl: string; // Full data URL for rendering in <img>
  name?: string;
  size?: number;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  image?: ChatImage;
  timestamp: number;
  isStreaming?: boolean;
  error?: string;
  feedback?: 'like' | 'dislike' | null;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  model: string;
  personaId: string;
}

export interface Persona {
  id: string;
  name: string;
  badge: string;
  icon: string;
  description: string;
  systemInstruction: string;
}

export interface ModelOption {
  id: string;
  name: string;
  tag: string;
  description: string;
  speed: string;
  intelligence: string;
}
