import React, { useState } from 'react';
import {
  Atom,
  Search,
  ExternalLink,
  Dna,
  BookOpen,
  Send,
  Loader2,
  FileText,
  AlertCircle,
  FlaskConical,
} from 'lucide-react';

interface ScienceWorkbenchProps {
  isOpen: boolean;
  onClose: () => void;
  onSendToChat: (query: string) => void;
}

export const ScienceWorkbench: React.FC<ScienceWorkbenchProps> = ({
  isOpen,
  onClose,
  onSendToChat,
}) => {
  const [activeTab, setActiveTab] = useState<'chemistry' | 'uniprot' | 'alphafold' | 'pubmed'>('chemistry');
  const [searchQuery, setSearchQuery] = useState('Aspirin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Results
  const [pubchemData, setPubchemData] = useState<any>(null);
  const [uniprotData, setUniprotData] = useState<any[]>([]);
  const [alphafoldData, setAlphafoldData] = useState<any>(null);
  const [pubmedData, setPubmedData] = useState<any[]>([]);

  if (!isOpen) return null;

  const quickPills = [
    { label: 'Aspirin', tab: 'chemistry' as const, query: 'Aspirin' },
    { label: 'TP53 (p53)', tab: 'uniprot' as const, query: 'TP53 human' },
    { label: 'P04637 (AlphaFold)', tab: 'alphafold' as const, query: 'P04637' },
    { label: 'Imatinib (Gleevec)', tab: 'chemistry' as const, query: 'Imatinib' },
    { label: 'CRISPR Gene Editing', tab: 'pubmed' as const, query: 'CRISPR Cas9 review' },
    { label: 'BRCA1', tab: 'uniprot' as const, query: 'BRCA1 human' },
  ];

  const handleSearch = async (tabToUse = activeTab, queryToUse = searchQuery) => {
    const q = queryToUse.trim();
    if (!q) return;

    setLoading(true);
    setError(null);

    try {
      if (tabToUse === 'chemistry') {
        const res = await fetch(`/api/science/pubchem?query=${encodeURIComponent(q)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Compound not found');
        setPubchemData(data);
      } else if (tabToUse === 'uniprot') {
        const res = await fetch(`/api/science/uniprot?query=${encodeURIComponent(q)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to search UniProt');
        setUniprotData(data);
      } else if (tabToUse === 'alphafold') {
        const res = await fetch(`/api/science/alphafold?accession=${encodeURIComponent(q)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Structure not found');
        setAlphafoldData(data);
      } else if (tabToUse === 'pubmed') {
        const res = await fetch(`/api/science/pubmed?query=${encodeURIComponent(q)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to search PubMed');
        setPubmedData(data.articles || []);
      }
    } catch (err: any) {
      console.error('Science query error:', err);
      setError(err.message || 'Error fetching scientific data');
    } finally {
      setLoading(false);
    }
  };

  const handlePillClick = (item: (typeof quickPills)[0]) => {
    setActiveTab(item.tab);
    setSearchQuery(item.query);
    handleSearch(item.tab, item.query);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl rounded-3xl bg-zinc-900 border border-zinc-750 shadow-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 p-[1.5px]">
              <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                <Atom className="w-5 h-5 text-teal-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  Science & Biomedical Scout
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-mono font-medium">
                  DeepMind Science
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Authoritative queries across PubChem, UniProtKB, AlphaFold DB & PubMed
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Quick Example Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-zinc-500 font-semibold shrink-0">Quick Try:</span>
          {quickPills.map((p, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handlePillClick(p)}
              className="shrink-0 px-2.5 py-1 rounded-lg bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-colors cursor-pointer text-[11px]"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-4 gap-2 border-b border-zinc-800 pb-3">
          <button
            onClick={() => {
              setActiveTab('chemistry');
              if (!pubchemData && searchQuery) handleSearch('chemistry', searchQuery);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'chemistry'
                ? 'bg-teal-500/20 border border-teal-500/50 text-teal-200'
                : 'bg-zinc-950 border border-zinc-800/80 text-zinc-400 hover:text-white'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5" />
            <span>PubChem</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('uniprot');
              if (uniprotData.length === 0 && searchQuery) handleSearch('uniprot', searchQuery);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'uniprot'
                ? 'bg-teal-500/20 border border-teal-500/50 text-teal-200'
                : 'bg-zinc-950 border border-zinc-800/80 text-zinc-400 hover:text-white'
            }`}
          >
            <Dna className="w-3.5 h-3.5" />
            <span>UniProtKB</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('alphafold');
              if (!alphafoldData && searchQuery) handleSearch('alphafold', searchQuery);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'alphafold'
                ? 'bg-teal-500/20 border border-teal-500/50 text-teal-200'
                : 'bg-zinc-950 border border-zinc-800/80 text-zinc-400 hover:text-white'
            }`}
          >
            <Atom className="w-3.5 h-3.5" />
            <span>AlphaFold DB</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('pubmed');
              if (pubmedData.length === 0 && searchQuery) handleSearch('pubmed', searchQuery);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
              activeTab === 'pubmed'
                ? 'bg-teal-500/20 border border-teal-500/50 text-teal-200'
                : 'bg-zinc-950 border border-zinc-800/80 text-zinc-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>PubMed</span>
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder={
                activeTab === 'chemistry'
                  ? 'Search compound by name or CID (e.g. Aspirin, Ibuprofen, 2244)...'
                  : activeTab === 'uniprot'
                  ? 'Search protein / gene (e.g. TP53 human, EGFR, Hemoglobin)...'
                  : activeTab === 'alphafold'
                  ? 'Enter UniProt accession ID (e.g. P04637, P00533, P68871)...'
                  : 'Search biomedical literature (e.g. mRNA vaccines, CRISPR Cas9)...'
              }
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-hidden focus:border-teal-500/70"
            />
          </div>
          <button
            type="button"
            onClick={() => handleSearch()}
            disabled={loading}
            className="px-5 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors shadow-sm"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>Search</span>
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Dynamic Tab Contents */}
        <div className="space-y-4 min-h-[220px]">
          {/* 1. PubChem View */}
          {activeTab === 'chemistry' && pubchemData && (
            <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div className="flex flex-col sm:flex-row gap-5 items-start">
                <div className="rounded-xl overflow-hidden bg-white p-2 border border-zinc-700 shadow-sm shrink-0">
                  <img
                    src={pubchemData.structureImageUrl}
                    alt={pubchemData.name}
                    className="w-40 h-40 object-contain"
                  />
                  <div className="text-[10px] text-center text-zinc-700 font-mono mt-1">
                    CID: {pubchemData.cid}
                  </div>
                </div>

                <div className="flex-1 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-bold text-white capitalize">
                      {pubchemData.name}
                    </h3>
                    <a
                      href={pubchemData.pubchemUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-teal-400 hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <span>PubChem Record</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
                    <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Formula</span>
                      <span className="text-white font-semibold">{pubchemData.formula}</span>
                    </div>
                    <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Molecular Weight</span>
                      <span className="text-white font-semibold">{pubchemData.molecularWeight} g/mol</span>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 font-mono text-[11px]">
                    <span className="text-zinc-500 block text-[10px]">IUPAC Name</span>
                    <span className="text-zinc-300 break-all">{pubchemData.iupacName}</span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 font-mono text-[11px]">
                    <span className="text-zinc-500 block text-[10px]">Canonical SMILES</span>
                    <span className="text-teal-300 break-all">{pubchemData.smiles}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => {
                    onSendToChat(`Analyze the chemical properties, pharmacological mechanism, and safety profile of ${pubchemData.name} (Formula: ${pubchemData.formula}, CID: ${pubchemData.cid}, SMILES: ${pubchemData.smiles}).`);
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-zinc-950 font-bold text-xs cursor-pointer transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Analyze Compound in Chat</span>
                </button>
              </div>
            </div>
          )}

          {/* 2. UniProtKB View */}
          {activeTab === 'uniprot' && uniprotData.length > 0 && (
            <div className="space-y-2">
              {uniprotData.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 transition-all flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-teal-300 text-xs">
                        {item.primaryAccession}
                      </span>
                      <span className="text-white font-semibold text-xs">
                        {item.proteinDescription?.recommendedName?.fullName?.value || item.uniProtkbId}
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-400">
                      Organism: <span className="text-zinc-300">{item.organism?.scientificName}</span> • Length: {item.sequence?.length} aa
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('alphafold');
                        setSearchQuery(item.primaryAccession);
                        handleSearch('alphafold', item.primaryAccession);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white text-[11px] font-medium cursor-pointer"
                    >
                      AlphaFold
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onSendToChat(`Explain the biological function, active domains, and disease associations of UniProt protein ${item.primaryAccession} (${item.uniProtkbId}).`);
                        onClose();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-teal-500 hover:bg-teal-400 text-zinc-950 text-[11px] font-bold cursor-pointer"
                    >
                      Ask ASTRA AI
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* 3. AlphaFold DB View */}
          {activeTab === 'alphafold' && alphafoldData && (
            <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">
                    {alphafoldData.gene || alphafoldData.uniprotAccession}
                  </h3>
                  <p className="text-xs text-zinc-400">
                    {alphafoldData.uniprotDescription || 'AlphaFold predicted structural model'}
                  </p>
                </div>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                  Global pLDDT: {alphafoldData.globalMetricValue ? Math.round(alphafoldData.globalMetricValue) : 'High'}
                </span>
              </div>

              {/* pLDDT Confidence Scale Visualizer */}
              <div className="space-y-1.5 p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-xs">
                <span className="text-zinc-400 font-semibold block text-[11px]">
                  AlphaFold Canonical pLDDT Confidence Scale
                </span>
                <div className="grid grid-cols-4 gap-1.5 text-[10px] text-center font-semibold pt-1">
                  <div className="p-1 rounded bg-[#0053D6] text-white">Very High (&gt;90)</div>
                  <div className="p-1 rounded bg-[#65CBF3] text-zinc-950">Confident (70-90)</div>
                  <div className="p-1 rounded bg-[#FFDB13] text-zinc-950">Low (50-70)</div>
                  <div className="p-1 rounded bg-[#FF7D45] text-white">Very Low (&lt;50)</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                {alphafoldData.pdbUrl && (
                  <a
                    href={alphafoldData.pdbUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-medium"
                  >
                    <span>Download PDB</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {alphafoldData.cifUrl && (
                  <a
                    href={alphafoldData.cifUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-medium"
                  >
                    <span>Download mmCIF</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {alphafoldData.paeDocUrl && (
                  <a
                    href={alphafoldData.paeDocUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-medium"
                  >
                    <span>PAE Matrix JSON</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              <div className="flex justify-end pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => {
                    onSendToChat(`Analyze the AlphaFold structural prediction for ${alphafoldData.uniprotAccession} (${alphafoldData.gene || ''}). What are the key domains, binding sites, and regions of high vs low pLDDT confidence?`);
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-zinc-950 font-bold text-xs cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Analyze Structure in Chat</span>
                </button>
              </div>
            </div>
          )}

          {/* 4. PubMed View */}
          {activeTab === 'pubmed' && pubmedData.length > 0 && (
            <div className="space-y-2.5">
              {pubmedData.map((art, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <h4 className="text-xs font-bold text-white hover:text-teal-300 leading-snug">
                      <a href={art.url} target="_blank" rel="noopener noreferrer">
                        {art.title}
                      </a>
                    </h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 shrink-0">
                      PMID: {art.pmid}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">
                    {art.authors} • <span className="italic text-zinc-300">{art.source}</span> ({art.pubdate})
                  </p>
                  <div className="flex justify-end pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        onSendToChat(`Summarize the key findings, methodology, and scientific implications of PubMed paper "${art.title}" (PMID: ${art.pmid}).`);
                        onClose();
                      }}
                      className="text-[11px] font-semibold text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      <span>Summarize paper in chat</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
