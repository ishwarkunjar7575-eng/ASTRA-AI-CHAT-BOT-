import React, { useMemo } from 'react';
import { marked, Token } from 'marked';
import DOMPurify from 'dompurify';
import { CodeBlock } from './CodeBlock';

interface MarkdownViewProps {
  content: string;
  isStreaming?: boolean;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content, isStreaming }) => {
  // Parse content into tokens
  const tokens = useMemo(() => {
    if (!content) return [];
    try {
      return marked.lexer(content);
    } catch (e) {
      console.error('Error lexing markdown:', e);
      return [];
    }
  }, [content]);

  if (!content) {
    return null;
  }

  // Fallback if marked fails to produce tokens
  if (tokens.length === 0) {
    return <div className="whitespace-pre-wrap">{content}</div>;
  }

  return (
    <div className="markdown-body space-y-3.5 leading-relaxed text-[15px]">
      {tokens.map((token: Token, index: number) => {
        if (token.type === 'code') {
          return (
            <CodeBlock
              key={`code-${index}`}
              code={token.text}
              language={token.lang || 'text'}
            />
          );
        }

        // For all other tokens, compile with marked and sanitize
        try {
          const rawHtml = marked.parser([token]) as string;
          const cleanHtml = DOMPurify.sanitize(rawHtml, {
            ADD_ATTR: ['target', 'rel'],
          });

          return (
            <div
              key={`token-${index}`}
              className="prose-content"
              dangerouslySetInnerHTML={{ __html: cleanHtml }}
            />
          );
        } catch (err) {
          return (
            <div key={`err-${index}`} className="whitespace-pre-wrap">
              {token.raw}
            </div>
          );
        }
      })}

      {isStreaming && (
        <span className="inline-block w-2 h-4 ml-1 bg-teal-400 animate-pulse rounded-sm align-middle" />
      )}
    </div>
  );
};
