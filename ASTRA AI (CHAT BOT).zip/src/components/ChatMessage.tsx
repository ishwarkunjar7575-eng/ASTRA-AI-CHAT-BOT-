import React, { useState, useRef } from 'react';
import {
  Sparkles,
  User,
  Copy,
  Check,
  RotateCcw,
  Volume2,
  VolumeX,
  ThumbsUp,
  ThumbsDown,
  Edit3,
  AlertTriangle,
} from 'lucide-react';
import { Message } from '../types';
import { MarkdownView } from './MarkdownView';

interface ChatMessageProps {
  message: Message;
  isLastModelMessage: boolean;
  onRegenerate?: () => void;
  onEditPrompt?: (text: string) => void;
  onFeedback?: (messageId: string, type: 'like' | 'dislike') => void;
  voiceName?: string;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  isLastModelMessage,
  onRegenerate,
  onEditPrompt,
  onFeedback,
  voiceName = 'Zephyr',
}) => {
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const isModel = message.role === 'model';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  const handleToggleSpeak = async () => {
    if (isPlayingAudio) {
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
        audioPlayerRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsPlayingAudio(false);
      return;
    }

    setIsLoadingAudio(true);

    try {
      // 1. Try Gemini Neural TTS
      const res = await fetch('/api/voice/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: message.text,
          voiceName,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.audio) {
        throw new Error(data.error || 'TTS error');
      }

      const audio = new Audio(`data:audio/wav;base64,${data.audio}`);
      audioPlayerRef.current = audio;
      audio.onended = () => {
        setIsPlayingAudio(false);
        audioPlayerRef.current = null;
      };
      audio.onerror = () => {
        setIsPlayingAudio(false);
      };

      setIsLoadingAudio(false);
      setIsPlayingAudio(true);
      await audio.play();
    } catch (err) {
      console.warn('Neural TTS unavailable, falling back to Web Speech synthesis:', err);
      setIsLoadingAudio(false);

      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(message.text);
        utterance.rate = 1.0;
        utterance.onend = () => setIsPlayingAudio(false);
        utterance.onerror = () => setIsPlayingAudio(false);

        setIsPlayingAudio(true);
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      className={`py-5 px-4 md:px-8 transition-colors ${
        isModel ? 'bg-zinc-950' : 'bg-zinc-900/40'
      }`}
    >
      <div className="max-w-3xl mx-auto flex gap-4 md:gap-5">
        {/* Avatar */}
        <div className="shrink-0 pt-0.5">
          {isModel ? (
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 p-[1.5px] shadow-md shadow-teal-500/10">
              <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-teal-300" />
              </div>
            </div>
          ) : (
            <div className="w-8 h-8 rounded-xl bg-zinc-800 border border-zinc-700/80 flex items-center justify-center text-zinc-300 shadow-sm">
              <User className="w-4 h-4" />
            </div>
          )}
        </div>

        {/* Content & Metadata */}
        <div className="flex-1 min-w-0 space-y-2">
          {/* Header row */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-zinc-200">
                {isModel ? 'ASTRA AI' : 'You'}
              </span>
              <span className="text-zinc-400 text-[11px]">{formattedTime}</span>
            </div>

            {/* User Edit Action */}
            {!isModel && onEditPrompt && (
              <button
                onClick={() => onEditPrompt(message.text)}
                title="Edit and resubmit message"
                className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-teal-400 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span>Edit</span>
              </button>
            )}
          </div>

          {/* Uploaded image preview */}
          {message.image && (
            <div className="pt-1 pb-2">
              <div className="relative inline-block rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900/50 max-w-sm group">
                <img
                  src={message.image.previewUrl}
                  alt={message.image.name || 'Attached input'}
                  className="max-h-72 w-auto object-contain rounded-xl"
                />
                {message.image.name && (
                  <div className="absolute bottom-0 inset-x-0 bg-black/70 backdrop-blur-xs px-2.5 py-1 text-[11px] text-zinc-300 truncate">
                    {message.image.name}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Message Text / Markdown */}
          {isModel ? (
            <div className="text-zinc-200 leading-relaxed">
              <MarkdownView
                content={message.text}
                isStreaming={message.isStreaming}
              />
            </div>
          ) : (
            <div className="text-zinc-100 text-[15px] whitespace-pre-wrap leading-relaxed">
              {message.text}
            </div>
          )}

          {/* Error Banner */}
          {message.error && (
            <div className="mt-3 p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-red-200 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-red-300">Generation error</p>
                <p className="text-red-400/90 mt-0.5">{message.error}</p>
                {onRegenerate && (
                  <button
                    onClick={onRegenerate}
                    className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-red-900/40 hover:bg-red-800/60 border border-red-700/60 text-white font-medium text-xs cursor-pointer transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Retry generation</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Action Toolbar for Model Messages */}
          {isModel && !message.isStreaming && message.text && (
            <div className="pt-2 flex items-center gap-1 text-zinc-400">
              <button
                onClick={handleCopy}
                title="Copy response"
                className="p-1.5 rounded-lg hover:text-white hover:bg-zinc-800/70 transition-colors cursor-pointer"
              >
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>

              <button
                onClick={handleToggleSpeak}
                title={isPlayingAudio ? 'Stop speaking' : 'Read aloud with Gemini Neural Voice'}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isPlayingAudio
                    ? 'text-teal-400 bg-teal-500/10'
                    : 'hover:text-white hover:bg-zinc-800/70'
                }`}
              >
                {isLoadingAudio ? (
                  <span className="w-3.5 h-3.5 block border-2 border-teal-400 border-t-transparent rounded-full animate-spin" />
                ) : isPlayingAudio ? (
                  <VolumeX className="w-3.5 h-3.5" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5" />
                )}
              </button>

              {isLastModelMessage && onRegenerate && (
                <button
                  onClick={onRegenerate}
                  title="Regenerate response"
                  className="p-1.5 rounded-lg hover:text-white hover:bg-zinc-800/70 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}

              {onFeedback && (
                <>
                  <button
                    onClick={() => onFeedback(message.id, 'like')}
                    title="Good response"
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      message.feedback === 'like'
                        ? 'text-teal-400 bg-teal-500/10'
                        : 'hover:text-white hover:bg-zinc-800/70'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onFeedback(message.id, 'dislike')}
                    title="Poor response"
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      message.feedback === 'dislike'
                        ? 'text-red-400 bg-red-500/10'
                        : 'hover:text-white hover:bg-zinc-800/70'
                    }`}
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
