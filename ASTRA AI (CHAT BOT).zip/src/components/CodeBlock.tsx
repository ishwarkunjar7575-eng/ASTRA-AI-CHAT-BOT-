import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface CodeBlockProps {
  code: string;
  language?: string;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ code, language = 'text' }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  const cleanLang = language ? language.toLowerCase().trim() : 'text';

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950 shadow-md">
      {/* Top language and copy bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-zinc-900/90 border-b border-zinc-800/80 text-xs text-zinc-400 select-none">
        <span className="font-mono uppercase tracking-wider font-semibold text-zinc-300">
          {cleanLang}
        </span>
        <button
          onClick={handleCopy}
          type="button"
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-zinc-300 hover:text-white bg-zinc-800/70 hover:bg-zinc-700/80 transition-all duration-150 cursor-pointer text-xs font-medium"
          title="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy code</span>
            </>
          )}
        </button>
      </div>

      {/* Code contents */}
      <div className="p-4 overflow-x-auto text-[13.5px] font-mono leading-relaxed text-zinc-100 selection:bg-teal-500/30 selection:text-teal-200">
        <pre className="m-0 p-0 font-mono whitespace-pre">
          <code>{code}</code>
        </pre>
      </div>
    </div>
  );
};
