import React from 'react';
import {
  Sparkles,
  Code2,
  Cpu,
  Lightbulb,
  FileText,
  Image,
  Zap,
  ShieldCheck,
  Brain,
} from 'lucide-react';
import { STARTER_PROMPTS } from '../constants';
import { Persona } from '../types';

interface WelcomeScreenProps {
  onSelectPrompt: (promptText: string) => void;
  selectedPersona: Persona;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectPrompt,
  selectedPersona,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code2':
        return <Code2 className="w-4 h-4 text-emerald-400" />;
      case 'Cpu':
        return <Cpu className="w-4 h-4 text-cyan-400" />;
      case 'Lightbulb':
        return <Lightbulb className="w-4 h-4 text-amber-400" />;
      case 'FileText':
        return <FileText className="w-4 h-4 text-teal-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-teal-400" />;
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 max-w-3xl mx-auto w-full text-center">
      {/* Emblem & Branding */}
      <div className="space-y-4 mb-8">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 p-[2px] shadow-2xl shadow-teal-500/20">
          <div className="w-full h-full bg-zinc-950 rounded-[22px] flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-teal-300 animate-pulse" />
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">
            <span className="bg-gradient-to-r from-teal-200 via-cyan-200 to-white bg-clip-text text-transparent">
              ASTRA AI
            </span>
          </h1>
          <p className="text-zinc-300 text-sm md:text-base max-w-md mx-auto">
            Your next-generation intelligence assistant.
          </p>
        </div>

        {/* Current Active Persona tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs text-zinc-300">
          <span className="w-2 h-2 rounded-full bg-teal-400" />
          <span>Active Mode:</span>
          <span className="text-teal-300 font-medium">
            {selectedPersona.name}
          </span>
        </div>
      </div>

      {/* Starter Prompts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl text-left">
        {STARTER_PROMPTS.map((item, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => onSelectPrompt(item.prompt)}
            className="p-3.5 rounded-2xl bg-zinc-900/60 hover:bg-zinc-850/90 border border-zinc-800/80 hover:border-teal-500/50 transition-all duration-200 flex flex-col justify-between gap-2.5 cursor-pointer group shadow-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-zinc-300 uppercase tracking-wider">
                {item.category}
              </span>
              <div className="p-1.5 rounded-lg bg-zinc-800/80 group-hover:bg-zinc-700 transition-colors">
                {getIcon(item.icon)}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-xs text-zinc-200 group-hover:text-white transition-colors">
                {item.title}
              </h3>
              <p className="text-[11px] text-zinc-400 line-clamp-2 mt-0.5 leading-snug">
                {item.prompt}
              </p>
            </div>
          </button>
        ))}
      </div>

      {/* Feature Highlights Footer */}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-2 text-xs text-zinc-300">
        <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900/40 border border-zinc-850">
          <Brain className="w-3.5 h-3.5 text-teal-400" />
          Multi-Turn Memory
        </span>
        <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900/40 border border-zinc-850">
          <Image className="w-3.5 h-3.5 text-cyan-400" />
          Vision & Images
        </span>
        <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900/40 border border-zinc-850">
          <Zap className="w-3.5 h-3.5 text-emerald-400" />
          Instant Streaming
        </span>
        <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900/40 border border-zinc-850">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
          Privacy First
        </span>
      </div>
    </div>
  );
};
