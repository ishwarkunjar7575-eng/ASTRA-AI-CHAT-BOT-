import React, { useState } from 'react';
import {
  X,
  Mic,
  Volume2,
  Sparkles,
  Play,
  Square,
  Radio,
  Sliders,
  Check,
} from 'lucide-react';
import { VOICE_OPTIONS } from '../constants';

interface VoiceAssistantPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedVoice: string;
  onSelectVoice: (voice: string) => void;
  onStartLiveCall: () => void;
  autoSpeak: boolean;
  onToggleAutoSpeak: (enabled: boolean) => void;
}

export const VoiceAssistantPanel: React.FC<VoiceAssistantPanelProps> = ({
  isOpen,
  onClose,
  selectedVoice,
  onSelectVoice,
  onStartLiveCall,
  autoSpeak,
  onToggleAutoSpeak,
}) => {
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const audioRef = React.useRef<HTMLAudioElement | null>(null);

  if (!isOpen) return null;

  const handleAuditionVoice = async (voice: (typeof VOICE_OPTIONS)[0]) => {
    if (playingVoiceId === voice.id) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setPlayingVoiceId(null);
      return;
    }

    try {
      setPlayingVoiceId(voice.id);
      const res = await fetch('/api/voice/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: voice.previewPhrase,
          voiceName: voice.id,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.audio) {
        throw new Error(data.error || 'TTS failed');
      }

      const audio = new Audio(`data:audio/wav;base64,${data.audio}`);
      audioRef.current = audio;
      audio.onended = () => {
        setPlayingVoiceId(null);
        audioRef.current = null;
      };
      audio.onerror = () => {
        setPlayingVoiceId(null);
      };
      await audio.play();
    } catch (e) {
      console.warn('Neural preview fallback to synthesis:', e);
      if ('speechSynthesis' in window) {
        const u = new SpeechSynthesisUtterance(voice.previewPhrase);
        u.onend = () => setPlayingVoiceId(null);
        window.speechSynthesis.speak(u);
      } else {
        setPlayingVoiceId(null);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-zinc-900 border border-zinc-750 shadow-2xl p-6 space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 p-[1.5px] shadow-lg shadow-teal-500/20">
              <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                <Mic className="w-5 h-5 text-teal-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Voice Assistant</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-medium">
                  Gemini Live
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Gemini 3.8 Live API & Neural Speech (24kHz HD Audio)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Big Start Call Action Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-teal-950/40 to-zinc-950 border border-teal-500/30 flex items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <h3 className="text-sm font-bold text-white">Real-Time Voice Call</h3>
            </div>
            <p className="text-xs text-zinc-300">
              Have an ultra-low latency spoken conversation with Gemini 3.8 Live.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              onClose();
              onStartLiveCall();
            }}
            className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 font-bold text-xs shadow-md shadow-teal-500/20 transition-all cursor-pointer"
          >
            <Mic className="w-4 h-4" />
            <span>Start Call</span>
          </button>
        </div>

        {/* Voice Persona Selector */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-teal-400" />
              <span>Choose Gemini Voice Persona</span>
            </label>
            <span className="text-[11px] text-zinc-500 font-mono">5 Neural Voices</span>
          </div>

          <div className="space-y-2">
            {VOICE_OPTIONS.map((voice) => {
              const isSelected = selectedVoice === voice.id;
              const isPlaying = playingVoiceId === voice.id;

              return (
                <div
                  key={voice.id}
                  onClick={() => onSelectVoice(voice.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-teal-500/10 border-teal-500/50 shadow-xs'
                      : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                        isSelected
                          ? 'bg-teal-500 text-zinc-950'
                          : 'bg-zinc-800 text-zinc-300'
                      }`}
                    >
                      {voice.name[0]}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-white">
                          {voice.name}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400">
                          {voice.gender}
                        </span>
                        {isSelected && (
                          <span className="text-[10px] text-teal-400 font-mono flex items-center gap-1">
                            <Check className="w-3 h-3" />
                            <span>Active</span>
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-zinc-400 truncate">
                        {voice.description}
                      </p>
                    </div>
                  </div>

                  {/* Audition Voice Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAuditionVoice(voice);
                    }}
                    title="Audition voice"
                    className={`p-2 rounded-xl transition-colors cursor-pointer shrink-0 ${
                      isPlaying
                        ? 'bg-teal-500 text-zinc-950 animate-pulse'
                        : 'bg-zinc-850 hover:bg-zinc-750 text-zinc-300 hover:text-white'
                    }`}
                  >
                    {isPlaying ? (
                      <Square className="w-3.5 h-3.5 fill-current" />
                    ) : (
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Auto-read responses setting */}
        <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-xs font-semibold text-white block">
              Auto-Read Incoming Answers
            </span>
            <span className="text-[11px] text-zinc-400 block">
              Automatically speak generated responses aloud in your chosen voice.
            </span>
          </div>
          <button
            type="button"
            onClick={() => onToggleAutoSpeak(!autoSpeak)}
            className={`w-11 h-6 rounded-full transition-colors p-0.5 cursor-pointer relative shrink-0 ${
              autoSpeak ? 'bg-teal-500' : 'bg-zinc-800'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                autoSpeak ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Close Button */}
        <div className="pt-1 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
