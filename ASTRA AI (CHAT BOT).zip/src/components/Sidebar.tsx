import React, { useState, useMemo } from 'react';
import {
  Plus,
  MessageSquare,
  Trash2,
  Edit2,
  Check,
  X,
  Search,
  Download,
  PanelLeftClose,
  Sparkles,
  Bot,
} from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  isOpen: boolean;
  onToggle: () => void;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onClearAllSessions: () => void;
  onExportSession: (session: ChatSession) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  isOpen,
  onToggle,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onClearAllSessions,
  onExportSession,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  // Filter sessions by search query
  const filteredSessions = useMemo(() => {
    if (!searchQuery.trim()) return sessions;
    const query = searchQuery.toLowerCase();
    return sessions.filter((s) => {
      const matchTitle = s.title.toLowerCase().includes(query);
      const matchMessages = s.messages.some((m) =>
        m.text.toLowerCase().includes(query)
      );
      return matchTitle || matchMessages;
    });
  }, [sessions, searchQuery]);

  // Group sessions by date
  const groupedSessions = useMemo(() => {
    const today: ChatSession[] = [];
    const yesterday: ChatSession[] = [];
    const last7Days: ChatSession[] = [];
    const older: ChatSession[] = [];

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 86400000;
    const startOf7Days = startOfToday - 7 * 86400000;

    filteredSessions.forEach((session) => {
      const time = session.updatedAt || session.createdAt;
      if (time >= startOfToday) {
        today.push(session);
      } else if (time >= startOfYesterday) {
        yesterday.push(session);
      } else if (time >= startOf7Days) {
        last7Days.push(session);
      } else {
        older.push(session);
      }
    });

    return [
      { label: 'Today', list: today },
      { label: 'Yesterday', list: yesterday },
      { label: 'Previous 7 Days', list: last7Days },
      { label: 'Older', list: older },
    ].filter((group) => group.list.length > 0);
  }, [filteredSessions]);

  const handleStartRename = (e: React.MouseEvent, session: ChatSession) => {
    e.stopPropagation();
    setEditingId(session.id);
    setEditTitle(session.title);
  };

  const handleSaveRename = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onToggle}
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-xs md:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 flex flex-col bg-zinc-950 border-r border-zinc-800/80 transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:hidden'
        }`}
      >
        {/* Top Header & New Chat button */}
        <div className="p-3.5 space-y-2.5 border-b border-zinc-800/80">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 px-1 py-1">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 p-[1.5px] flex items-center justify-center shadow-lg shadow-teal-500/10">
                <div className="w-full h-full bg-zinc-950 rounded-[7px] flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-teal-300" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-base tracking-tight bg-gradient-to-r from-teal-200 via-cyan-200 to-white bg-clip-text text-transparent">
                  ASTRA AI
                </span>
                <span className="text-[10px] uppercase tracking-wider font-semibold text-zinc-300">
                  AI Companion
                </span>
              </div>
            </div>

            <button
              onClick={onToggle}
              title="Close sidebar"
              className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 transition-colors cursor-pointer"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
          </div>

          {/* New Chat Button */}
          <button
            onClick={onNewChat}
            type="button"
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-750/70 hover:border-teal-500/50 text-zinc-100 font-medium text-sm transition-all duration-200 shadow-sm cursor-pointer group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-6 h-6 rounded-md bg-teal-500/20 text-teal-300 flex items-center justify-center group-hover:bg-teal-500 group-hover:text-zinc-950 transition-colors">
                <Plus className="w-4 h-4" />
              </div>
              <span>New conversation</span>
            </div>
            <span className="text-[11px] text-zinc-300 bg-zinc-800 px-1.5 py-0.5 rounded font-mono">
              Ctrl+K
            </span>
          </button>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-300" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-zinc-900/80 border border-zinc-800 text-xs text-zinc-200 placeholder-zinc-400 focus:outline-hidden focus:border-teal-500/60 focus:bg-zinc-900 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-200 p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Sessions list */}
        <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
          {groupedSessions.length === 0 ? (
            <div className="px-4 py-8 text-center text-xs text-zinc-400 space-y-1.5">
              <Bot className="w-8 h-8 mx-auto text-zinc-400 opacity-60" />
              <p className="font-medium text-zinc-300">No conversations found</p>
              <p className="text-[11px]">Start a new chat to begin exploring</p>
            </div>
          ) : (
            groupedSessions.map((group) => (
              <div key={group.label} className="space-y-1">
                <div className="px-3 py-1 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                  {group.label}
                </div>
                <div className="space-y-0.5">
                  {group.list.map((session) => {
                    const isSelected = session.id === currentSessionId;
                    const isEditing = session.id === editingId;

                    return (
                      <div
                        key={session.id}
                        onClick={() => onSelectSession(session.id)}
                        className={`group relative flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium cursor-pointer transition-all duration-150 ${
                          isSelected
                            ? 'bg-zinc-850 text-white shadow-xs border border-zinc-700/80'
                            : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/80 border border-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1 mr-1">
                          <MessageSquare
                            className={`w-3.5 h-3.5 shrink-0 transition-colors ${
                              isSelected ? 'text-teal-400' : 'text-zinc-300 group-hover:text-zinc-400'
                            }`}
                          />

                          {isEditing ? (
                            <input
                              type="text"
                              autoFocus
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              onClick={(e) => e.stopPropagation()}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSaveRename(e as any, session.id);
                                if (e.key === 'Escape') setEditingId(null);
                              }}
                              className="w-full bg-zinc-950 border border-teal-500 rounded px-1.5 py-0.5 text-xs text-white focus:outline-hidden"
                            />
                          ) : (
                            <span className="truncate">{session.title}</span>
                          )}
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-1 shrink-0">
                          {isEditing ? (
                            <>
                              <button
                                onClick={(e) => handleSaveRename(e, session.id)}
                                title="Save title"
                                className="p-1 hover:text-teal-400 text-zinc-400"
                              >
                                <Check className="w-3 h-3" />
                              </button>
                              <button
                                onClick={handleCancelRename}
                                title="Cancel"
                                className="p-1 hover:text-red-400 text-zinc-400"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </>
                          ) : (
                            <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity gap-0.5">
                              <button
                                onClick={(e) => handleStartRename(e, session)}
                                title="Rename chat"
                                className="p-1 hover:text-zinc-100 text-zinc-400 rounded hover:bg-zinc-800"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onExportSession(session);
                                }}
                                title="Export chat"
                                className="p-1 hover:text-zinc-100 text-zinc-400 rounded hover:bg-zinc-800"
                              >
                                <Download className="w-3 h-3" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onDeleteSession(session.id);
                                }}
                                title="Delete chat"
                                className="p-1 hover:text-red-400 text-zinc-400 rounded hover:bg-zinc-800"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-zinc-800/80 bg-zinc-950/80 space-y-2">
          {sessions.length > 0 && (
            <button
              onClick={onClearAllSessions}
              className="w-full flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg text-xs text-zinc-400 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear all conversations</span>
            </button>
          )}

          <div className="flex items-center justify-between pt-1 px-1 text-[11px] text-zinc-300">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Gemini Powered
            </span>
            <span className="font-mono">v1.2.0</span>
          </div>
        </div>
      </aside>
    </>
  );
};
