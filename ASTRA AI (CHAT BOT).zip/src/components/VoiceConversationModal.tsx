import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  PhoneOff,
  Sparkles,
  Volume2,
  AlertCircle,
  Radio,
  Send,
  RotateCcw,
  Sliders,
} from 'lucide-react';
import { VOICE_OPTIONS } from '../constants';

interface VoiceConversationModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedVoice?: string;
  onSelectVoice?: (voice: string) => void;
}

interface TranscriptTurn {
  role: 'user' | 'assistant';
  text: string;
  time: string;
}

export const VoiceConversationModal: React.FC<VoiceConversationModalProps> = ({
  isOpen,
  onClose,
  selectedVoice = 'Zephyr',
  onSelectVoice,
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [statusText, setStatusText] = useState('Connecting to Gemini 3.8 Live...');
  const [errorText, setErrorText] = useState<string | null>(null);
  const [isPermissionDenied, setIsPermissionDenied] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [typedMessage, setTypedMessage] = useState('');
  const [activeVoice, setActiveVoice] = useState(selectedVoice);
  const [transcript, setTranscript] = useState<TranscriptTurn[]>([]);
  const [voiceDropdownOpen, setVoiceDropdownOpen] = useState(false);

  const activeVoiceOption = VOICE_OPTIONS.find((v) => v.id === activeVoice);
  const activeVoiceDisplayName = activeVoiceOption ? activeVoiceOption.name : 'Natural';

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioQueueRef = useRef<AudioBufferSourceNode[]>([]);
  const nextPlayTimeRef = useRef<number>(0);
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setActiveVoice(selectedVoice);
  }, [selectedVoice]);

  useEffect(() => {
    if (!isOpen) {
      cleanup();
      return;
    }

    startLiveSession(activeVoice);

    return () => {
      cleanup();
    };
  }, [isOpen, activeVoice]);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  const cleanup = () => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (inputAudioCtxRef.current && inputAudioCtxRef.current.state !== 'closed') {
      inputAudioCtxRef.current.close().catch(() => {});
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current && outputAudioCtxRef.current.state !== 'closed') {
      outputAudioCtxRef.current.close().catch(() => {});
      outputAudioCtxRef.current = null;
    }

    audioQueueRef.current.forEach((src) => {
      try {
        src.stop();
      } catch (e) {}
    });
    audioQueueRef.current = [];
    nextPlayTimeRef.current = 0;

    setIsConnected(false);
    setIsAiSpeaking(false);
    setErrorText(null);
    setIsPermissionDenied(false);
  };

  const startLiveSession = async (voiceToUse = activeVoice) => {
    setErrorText(null);
    setIsPermissionDenied(false);
    setStatusText('Connecting to Voice Assistant...');

    try {
      if (!outputAudioCtxRef.current || outputAudioCtxRef.current.state === 'closed') {
        outputAudioCtxRef.current = new (window.AudioContext ||
          (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
    } catch (e) {
      console.warn('Could not initialize output AudioContext:', e);
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/live?voice=${encodeURIComponent(
      voiceToUse
    )}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      setStatusText('Voice Assistant online. Speak or type below.');
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.error) {
          setErrorText(data.error);
          setStatusText('Error in Live API session');
        } else if (data.interrupted) {
          stopAudioQueue();
          setIsAiSpeaking(false);
        } else if (data.audio) {
          setIsAiSpeaking(true);
          playAudioChunk(data.audio);
        }
      } catch (err) {
        console.error('Failed to parse WS message:', err);
      }
    };

    ws.onerror = (e) => {
      console.error('Live WebSocket error:', e);
      setErrorText('Live session connection interrupted.');
    };

    ws.onclose = () => {
      setIsConnected(false);
      setStatusText('Session closed.');
    };

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        },
      });
      mediaStreamRef.current = stream;

      inputAudioCtxRef.current = new (window.AudioContext ||
        (window as any).webkitAudioContext)({ sampleRate: 16000 });

      startMicCapture();
    } catch (err: any) {
      console.warn('Microphone access warning:', err);
      const isDenied =
        err?.name === 'NotAllowedError' ||
        err?.name === 'PermissionDeniedError' ||
        err?.message?.toLowerCase().includes('permission denied');

      if (isDenied) {
        setIsPermissionDenied(true);
        setErrorText(
          'Microphone permission denied. Allow microphone access in your browser or type below.'
        );
      } else {
        setErrorText(
          err instanceof Error ? err.message : 'Unable to access microphone device.'
        );
      }
      setStatusText('Microphone unavailable. You can type below to hear Gemini Live.');
    }
  };

  const startMicCapture = () => {
    if (!inputAudioCtxRef.current || !mediaStreamRef.current) return;

    const source = inputAudioCtxRef.current.createMediaStreamSource(
      mediaStreamRef.current
    );
    const processor = inputAudioCtxRef.current.createScriptProcessor(4096, 1, 1);

    source.connect(processor);
    processor.connect(inputAudioCtxRef.current.destination);

    processor.onaudioprocess = (e) => {
      if (isMuted || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        return;
      }

      const inputData = e.inputBuffer.getChannelData(0);
      const base64Pcm = floatTo16BitPCMBase64(inputData);

      wsRef.current.send(
        JSON.stringify({
          audio: base64Pcm,
        })
      );
    };
  };

  const floatTo16BitPCMBase64 = (input: Float32Array): string => {
    const buffer = new ArrayBuffer(input.length * 2);
    const view = new DataView(buffer);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const playAudioChunk = (base64Audio: string) => {
    const ctx = outputAudioCtxRef.current;
    if (!ctx) return;

    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const binaryString = atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }

    const audioBuffer = ctx.createBuffer(1, float32Array.length, 24000);
    audioBuffer.getChannelData(0).set(float32Array);

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);

    const currentTime = ctx.currentTime;
    if (nextPlayTimeRef.current < currentTime) {
      nextPlayTimeRef.current = currentTime;
    }

    source.start(nextPlayTimeRef.current);
    nextPlayTimeRef.current += audioBuffer.duration;

    audioQueueRef.current.push(source);
    source.onended = () => {
      audioQueueRef.current = audioQueueRef.current.filter((s) => s !== source);
      if (audioQueueRef.current.length === 0) {
        setIsAiSpeaking(false);
      }
    };
  };

  const stopAudioQueue = () => {
    audioQueueRef.current.forEach((src) => {
      try {
        src.stop();
      } catch (e) {}
    });
    audioQueueRef.current = [];
    if (outputAudioCtxRef.current) {
      nextPlayTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleSendTextMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = typedMessage.trim();
    if (!text || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    if (outputAudioCtxRef.current?.state === 'suspended') {
      outputAudioCtxRef.current.resume().catch(() => {});
    }

    wsRef.current.send(JSON.stringify({ text }));

    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setTranscript((prev) => [
      ...prev,
      { role: 'user', text, time: now },
    ]);

    setTypedMessage('');
    setStatusText(`Sent: "${text}". Listening for response...`);
  };

  const handleVoiceChange = (v: string) => {
    setActiveVoice(v);
    onSelectVoice?.(v);
    setVoiceDropdownOpen(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-zinc-900 border border-zinc-750 shadow-2xl p-6 text-center space-y-5 flex flex-col items-center max-h-[92vh] overflow-y-auto">
        {/* Top Header with Voice Persona Dropdown */}
        <div className="w-full flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-800/80 border border-zinc-700/60 text-xs font-semibold text-zinc-300">
              <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>Gemini 3.8 Live</span>
            </div>

            {/* Voice Persona Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setVoiceDropdownOpen(!voiceDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-semibold hover:bg-teal-500/20 transition-colors cursor-pointer"
              >
                <Sliders className="w-3 h-3" />
                <span>Voice: {activeVoiceDisplayName}</span>
              </button>

              {voiceDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setVoiceDropdownOpen(false)}
                  />
                  <div className="absolute left-0 mt-2 w-48 rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 text-left">
                    {VOICE_OPTIONS.map((v) => (
                      <button
                        key={v.id}
                        type="button"
                        onClick={() => handleVoiceChange(v.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium cursor-pointer transition-colors ${
                          activeVoice === v.id
                            ? 'bg-teal-500 text-zinc-950 font-bold'
                            : 'text-zinc-300 hover:bg-zinc-850'
                        }`}
                      >
                        {v.name} ({v.gender})
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Dynamic Glowing Sphere / Visualizer */}
        <div className="relative my-2 flex items-center justify-center">
          <div
            className={`w-32 h-32 rounded-full transition-all duration-300 flex items-center justify-center shadow-2xl ${
              isAiSpeaking
                ? 'bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 scale-110 shadow-cyan-500/30 animate-pulse'
                : isConnected && !isPermissionDenied
                ? 'bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-500 shadow-teal-500/20'
                : 'bg-zinc-800'
            }`}
          >
            <div className="w-24 h-24 rounded-full bg-zinc-950 flex flex-col items-center justify-center gap-1">
              {isAiSpeaking ? (
                <Volume2 className="w-7 h-7 text-cyan-300 animate-bounce" />
              ) : (
                <Sparkles className="w-7 h-7 text-teal-300" />
              )}
              <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">
                {isAiSpeaking
                  ? 'Speaking'
                  : isConnected && !isPermissionDenied
                  ? 'Listening'
                  : 'Ready'}
              </span>
            </div>
          </div>

          {isConnected && !isPermissionDenied && (
            <div className="absolute -inset-4 rounded-full border border-teal-500/30 animate-ping opacity-30 pointer-events-none" />
          )}
        </div>

        {/* Status Text & Permission Notice */}
        <div className="space-y-1.5 max-w-sm">
          <h3 className="text-sm font-bold text-white tracking-tight">
            {isAiSpeaking
              ? 'ASTRA AI is speaking...'
              : isConnected && !isPermissionDenied
              ? 'Listening... Speak freely'
              : isPermissionDenied
              ? 'Microphone Permission Needed'
              : 'Connecting...'}
          </h3>
          <p className="text-xs text-zinc-400 leading-relaxed">{statusText}</p>

          {isPermissionDenied && (
            <div className="mt-2 p-3 rounded-2xl bg-amber-950/40 border border-amber-800/80 text-amber-200 text-xs text-left space-y-2">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="leading-snug">
                  <p className="font-semibold text-amber-300">How to enable mic:</p>
                  <p className="text-[11px] text-amber-200/90 mt-0.5">
                    Click the 🔒 lock icon in your browser URL bar, set Microphone to <strong>Allow</strong>, then click Retry below.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => startLiveSession(activeVoice)}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs cursor-pointer transition-colors shadow-sm"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry Microphone Permission</span>
              </button>
            </div>
          )}

          {errorText && !isPermissionDenied && (
            <div className="p-2.5 rounded-xl bg-red-950/50 border border-red-800 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span className="text-left">{errorText}</span>
            </div>
          )}
        </div>

        {/* Live Conversation Transcript Box */}
        {transcript.length > 0 && (
          <div className="w-full max-h-36 overflow-y-auto rounded-2xl bg-zinc-950/90 border border-zinc-800 p-3 space-y-2 text-left text-xs">
            {transcript.map((item, idx) => (
              <div key={idx} className="space-y-0.5">
                <div className="flex items-center justify-between text-[10px] text-zinc-500">
                  <span className="font-semibold text-zinc-400">
                    {item.role === 'user' ? 'You' : 'ASTRA AI'}
                  </span>
                  <span>{item.time}</span>
                </div>
                <p className="text-zinc-200 leading-snug">{item.text}</p>
              </div>
            ))}
            <div ref={transcriptEndRef} />
          </div>
        )}

        {/* Text fallback input for typing */}
        <form
          onSubmit={handleSendTextMessage}
          className="w-full flex items-center gap-2 bg-zinc-950 border border-zinc-800 rounded-2xl p-1.5 focus-within:border-teal-500/70"
        >
          <input
            type="text"
            value={typedMessage}
            onChange={(e) => setTypedMessage(e.target.value)}
            placeholder="Type to talk with Live Assistant..."
            className="flex-1 bg-transparent text-xs text-white placeholder-zinc-500 px-3 py-1.5 focus:outline-hidden"
          />
          <button
            type="submit"
            disabled={!typedMessage.trim() || !isConnected}
            className="p-2 rounded-xl bg-teal-400 hover:bg-teal-300 disabled:opacity-40 text-zinc-950 transition-colors cursor-pointer"
            title="Send text to Gemini Live"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Action Controls */}
        <div className="flex items-center justify-center gap-4 pt-1">
          {!isPermissionDenied && (
            <button
              onClick={handleToggleMute}
              type="button"
              title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
              className={`p-3.5 rounded-2xl transition-all cursor-pointer ${
                isMuted
                  ? 'bg-red-500/20 border border-red-500/40 text-red-300'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
              }`}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          )}

          <button
            onClick={onClose}
            type="button"
            title="End voice conversation"
            className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs shadow-lg shadow-red-600/30 transition-all cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            <span>End Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};
