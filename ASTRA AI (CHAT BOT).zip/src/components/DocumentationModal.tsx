import React, { useState } from 'react';
import {
  X,
  Printer,
  Download,
  BookOpen,
  Sparkles,
  Cpu,
  Mic,
  Database,
  Globe,
  Atom,
  GraduationCap,
  FileCheck,
  User,
  Building,
  Hash,
  FileText,
  Loader2,
  Calendar,
} from 'lucide-react';
import { generateCollegeReportPdf, generateDocumentationPdf } from '../utils/generatePdf';

interface DocumentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DocumentationModal: React.FC<DocumentationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'college' | 'technical'>('college');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // College submission details
  const [studentName, setStudentName] = useState('Ishwar Kunjar');
  const [collegeName, setCollegeName] = useState('College of Engineering & Technology');
  const [rollNumber, setRollNumber] = useState('CSE-2026-ASTRA');
  const [department, setDepartment] = useState('Department of Computer Science & Engineering');
  const [academicYear, setAcademicYear] = useState('2025 - 2026');

  if (!isOpen) return null;

  const handleDownloadCollegePdf = () => {
    try {
      setIsGeneratingPdf(true);
      generateCollegeReportPdf({
        studentName,
        collegeName,
        rollNumber,
        department,
        academicYear,
      });
    } catch (err) {
      console.error('Failed to generate College PDF:', err);
      window.print();
    } finally {
      setTimeout(() => setIsGeneratingPdf(false), 900);
    }
  };

  const handleDownloadTechnicalPdf = () => {
    try {
      setIsGeneratingPdf(true);
      generateDocumentationPdf();
    } catch (err) {
      console.error('Failed to generate Technical PDF:', err);
      window.print();
    } finally {
      setTimeout(() => setIsGeneratingPdf(false), 900);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadMarkdown = () => {
    fetch('/DOCUMENTATION.md')
      .then((res) => {
        if (!res.ok) throw new Error('File not found');
        return res.text();
      })
      .catch(() => {
        return `# ASTRA AI — College Project Report & Documentation\n\nSubmitted by ${studentName} (${rollNumber}) - ${collegeName}.`;
      })
      .then((text) => {
        const blob = new Blob([text], { type: 'text/markdown;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'ASTRA_AI_PROJECT_REPORT.md');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl rounded-3xl bg-zinc-900 border border-zinc-750 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:p-5 border-b border-zinc-800 bg-zinc-950/90 gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-500 via-cyan-400 to-emerald-400 p-[1.5px] shadow-lg shadow-teal-500/20">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-teal-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  College Project Submission & System Manual
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300">
                  Ready to Submit
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Official Capstone Project Report for College / University Submission
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            {activeTab === 'college' ? (
              <button
                onClick={handleDownloadCollegePdf}
                disabled={isGeneratingPdf}
                type="button"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 text-xs font-bold transition-all cursor-pointer shadow-md shadow-teal-500/20 disabled:opacity-50"
                title="Download College Project Report PDF with Title Page & Certificate"
              >
                {isGeneratingPdf ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>Download College Report PDF</span>
              </button>
            ) : (
              <button
                onClick={handleDownloadTechnicalPdf}
                disabled={isGeneratingPdf}
                type="button"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 text-xs font-bold transition-all cursor-pointer shadow-md shadow-teal-500/20 disabled:opacity-50"
                title="Download Technical System Manual PDF"
              >
                {isGeneratingPdf ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>Download Technical Manual PDF</span>
              </button>
            )}

            <button
              onClick={handlePrint}
              type="button"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition-colors cursor-pointer"
              title="Print document or Save as PDF via system dialog"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Print to PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center px-5 pt-3 pb-2 border-b border-zinc-800 bg-zinc-950/50 gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('college')}
            type="button"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'college'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Academic Project Report (College Submission)</span>
          </button>
          <button
            onClick={() => setActiveTab('technical')}
            type="button"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'technical'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Technical System Manual (API & Specs)</span>
          </button>
        </div>

        {/* Customizable Student Info Bar for College Submission */}
        {activeTab === 'college' && (
          <div className="p-4 bg-zinc-950/80 border-b border-zinc-800 shrink-0">
            <div className="text-[11px] font-semibold text-teal-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <FileCheck className="w-3.5 h-3.5" />
              <span>Customize Student & College Details (Included on PDF Cover & Certificate)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 text-xs">
              <div>
                <label className="text-[10px] text-zinc-400 flex items-center gap-1 mb-1">
                  <User className="w-3 h-3 text-teal-400" /> Student Name
                </label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-750 rounded-xl px-2.5 py-1.5 text-zinc-100 text-xs focus:outline-hidden focus:border-teal-500"
                  placeholder="e.g. Ishwar Kunjar"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 flex items-center gap-1 mb-1">
                  <Hash className="w-3 h-3 text-cyan-400" /> Roll / ID Number
                </label>
                <input
                  type="text"
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-750 rounded-xl px-2.5 py-1.5 text-zinc-100 text-xs focus:outline-hidden focus:border-teal-500"
                  placeholder="e.g. CSE-2026-ASTRA"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 flex items-center gap-1 mb-1">
                  <Building className="w-3 h-3 text-emerald-400" /> College / University
                </label>
                <input
                  type="text"
                  value={collegeName}
                  onChange={(e) => setCollegeName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-750 rounded-xl px-2.5 py-1.5 text-zinc-100 text-xs focus:outline-hidden focus:border-teal-500"
                  placeholder="e.g. College of Engineering"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 flex items-center gap-1 mb-1">
                  <Calendar className="w-3 h-3 text-amber-400" /> Academic Session
                </label>
                <input
                  type="text"
                  value={academicYear}
                  onChange={(e) => setAcademicYear(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-750 rounded-xl px-2.5 py-1.5 text-zinc-100 text-xs focus:outline-hidden focus:border-teal-500"
                  placeholder="e.g. 2025 - 2026"
                />
              </div>
            </div>
          </div>
        )}

        {/* Scrollable Document Body (Printable Area) */}
        <div
          id="astra-printable-docs"
          className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-8 text-xs text-zinc-300 leading-relaxed bg-zinc-900"
        >
          {activeTab === 'college' ? (
            /* COLLEGE SUBMISSION PREVIEW */
            <div className="space-y-8 max-w-3xl mx-auto">
              {/* Formal Report Cover Card */}
              <div className="p-6 rounded-2xl bg-zinc-950 border-2 border-teal-500/40 text-center space-y-4">
                <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-widest block">
                  CAPSTONE PROJECT REPORT
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  ASTRA AI: Next-Generation Multimodal Conversational Intelligence & DeepMind Science Platform
                </h1>
                <p className="text-xs text-zinc-400 max-w-xl mx-auto leading-relaxed">
                  Submitted in partial fulfillment of the requirements for the degree of Bachelor of Technology in {department}.
                </p>

                <div className="pt-4 border-t border-zinc-800 grid grid-cols-1 sm:grid-cols-2 gap-3 text-left text-xs bg-zinc-900/60 p-4 rounded-xl">
                  <div>
                    <span className="text-[10px] font-bold text-teal-400 uppercase block">Submitted By</span>
                    <span className="text-white font-bold">{studentName}</span>
                    <span className="text-zinc-400 block text-[11px]">Roll No: {rollNumber}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-teal-400 uppercase block">Institution</span>
                    <span className="text-white font-bold">{collegeName}</span>
                    <span className="text-zinc-400 block text-[11px]">{department} • {academicYear}</span>
                  </div>
                </div>
              </div>

              {/* Certificate & Abstract */}
              <section className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <FileCheck className="w-4 h-4 text-teal-400" />
                  <h3>Bonafide Certificate & Abstract</h3>
                </div>
                <p className="text-zinc-300 italic text-[11px] leading-relaxed">
                  "This is to certify that the project report entitled 'ASTRA AI' is a bonafide record of work carried out by {studentName} ({rollNumber}) during the academic session {academicYear} in {department}, {collegeName}."
                </p>
                <div className="pt-2 border-t border-zinc-850">
                  <h4 className="text-xs font-bold text-teal-300 uppercase mb-1">Abstract</h4>
                  <p className="text-zinc-400 leading-relaxed text-[11px]">
                    Standard web chatbots suffer from API key exposure on clients, buffering latency in single-payload answers, lack of live speech-to-speech interaction, and hallucinations when handling biomedical inquiries. ASTRA AI solves these limitations through a resilient Node.js 22 full-stack Express gateway, Server-Sent Events (SSE) streaming with automatic failover, bidirectional WebSocket voice interaction with active speech interruption using <code>gemini-3.8-live</code>, and an integrated DeepMind Science workbench connecting directly to PubChem, UniProtKB, AlphaFold DB, and PubMed.
                  </p>
                </div>
              </section>

              {/* Chapter 1: Introduction */}
              <section className="space-y-3">
                <h3 className="text-sm font-bold text-white border-b border-zinc-800 pb-1.5 flex items-center gap-2">
                  <span className="text-teal-400 font-mono">01.</span> Introduction & Objectives
                </h3>
                <p>
                  Conversational artificial intelligence has transitioned from rules-based engines to generative foundation models. However, production web deployments face major architectural hurdles:
                </p>
                <ul className="list-disc list-inside space-y-1 text-zinc-400 text-[11px]">
                  <li><strong>Security:</strong> Preventing API key extraction from browser network inspectors.</li>
                  <li><strong>Responsiveness:</strong> Streaming tokens chunk-by-chunk to achieve sub-400ms time-to-first-token.</li>
                  <li><strong>Voice Multimodality:</strong> Bi-directional 16kHz audio capture and 24kHz synthesized output with real-time interruption.</li>
                  <li><strong>Scientific Verifiability:</strong> Grounding chemical, genomic, and structural queries in public peer-reviewed repositories.</li>
                </ul>
              </section>

              {/* Chapter 2: Technology Stack */}
              <section className="space-y-3">
                <h3 className="text-sm font-bold text-white border-b border-zinc-800 pb-1.5 flex items-center gap-2">
                  <span className="text-teal-400 font-mono">02.</span> System Architecture & Technology Stack
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-[11px]">
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <span className="font-bold text-teal-400 block">Frontend Tier</span>
                    <span className="text-white">React 19, TypeScript, Vite 8, Tailwind CSS v4</span>
                    <p className="text-zinc-400 mt-1">Componentized reactive state, Web Audio API ScriptProcessor, and Markdown prose styling.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <span className="font-bold text-cyan-400 block">Backend Gateway</span>
                    <span className="text-white">Node.js 22, Express 4.21, WebSockets (ws)</span>
                    <p className="text-zinc-400 mt-1">API key protection, unbuffered SSE token streaming, and binary audio socket relay.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <span className="font-bold text-emerald-400 block">Foundation AI</span>
                    <span className="text-white">Google GenAI TypeScript SDK (@google/genai)</span>
                    <p className="text-zinc-400 mt-1">Multi-model suite: Gemini 3.8 Flash, 3.5 Flash Grounding, 3.1 Pro, 3.8 Live, and Nano Banana 2.1.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <span className="font-bold text-amber-400 block">Database & Security</span>
                    <span className="text-white">Firebase Auth & Cloud Firestore (ABAC Rules)</span>
                    <p className="text-zinc-400 mt-1">Zero-trust security rules with Google OAuth and offline localStorage replication.</p>
                  </div>
                </div>
              </section>

              {/* Chapter 3: Key Modules */}
              <section className="space-y-3">
                <h3 className="text-sm font-bold text-white border-b border-zinc-800 pb-1.5 flex items-center gap-2">
                  <span className="text-teal-400 font-mono">03.</span> Core Modules & Implementation
                </h3>
                <div className="space-y-2 text-[11px]">
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <strong className="text-white">Module 1 — Dynamic Token Streaming & Failover:</strong> Uses Server-Sent Events with <code>X-Accel-Buffering: no</code>. Automatically routes from <code>gemini-3.8-flash</code> to <code>gemini-3.1-flash-lite</code> if 503 high-demand limits occur.
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <strong className="text-white">Module 2 — Bidirectional Live Speech (Gemini 3.8 Live):</strong> Streams 16kHz PCM microphone audio over WebSocket to Gemini Live. Plays 24kHz audio turns and flushes local audio buffers immediately when the user interrupts.
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <strong className="text-white">Module 3 — DeepMind Science Workbench:</strong> Integrates REST endpoints for PubChem (formulas, SMILES, 2D diagrams), UniProtKB (protein sequences), AlphaFold DB (3D structure mmCIF/PDB & pLDDT confidence scores), and NCBI PubMed (peer-reviewed citations).
                  </div>
                  <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                    <strong className="text-white">Module 4 — Grounding & Multimodal Image Studio:</strong> Live Google Search grounding, Google Maps geospatial tools, and text-to-image synthesis using <code>gemini-nano-banana-2.1</code>.
                  </div>
                </div>
              </section>

              {/* Chapter 4: Results & Conclusion */}
              <section className="space-y-3">
                <h3 className="text-sm font-bold text-white border-b border-zinc-800 pb-1.5 flex items-center gap-2">
                  <span className="text-teal-400 font-mono">04.</span> Results & Project Conclusion
                </h3>
                <p>
                  Experimental validation demonstrates an average Time-to-First-Token of <strong>~320ms</strong> on <code>gemini-3.8-flash</code> and <strong>~180ms</strong> on <code>gemini-3.1-flash-lite</code>. Live voice speech interruptions take effect within <strong>&lt;150ms</strong>. The project represents a complete, production-ready, cloud-deployable capstone system.
                </p>
                <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 text-[10px] text-zinc-400">
                  <strong className="text-teal-300 block mb-1">Academic References:</strong>
                  1. Google DeepMind, "Gemini: A Family of Highly Capable Multimodal Models", Tech Report, 2024.<br />
                  2. Jumper, J. et al., "Highly accurate protein structure prediction with AlphaFold", Nature 596, 2021.<br />
                  3. Kim, S. et al., "PubChem 2023 update", Nucleic Acids Research, 2023.
                </div>
              </section>
            </div>
          ) : (
            /* TECHNICAL SPECIFICATION MANUAL */
            <div className="space-y-8 max-w-3xl mx-auto">
              {/* Title Hero */}
              <div className="border-b border-zinc-800 pb-6 space-y-2">
                <span className="text-xs font-mono font-semibold text-teal-400 uppercase tracking-widest">
                  OFFICIAL SYSTEM MANUAL
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  ASTRA AI Technical Documentation
                </h1>
                <p className="text-sm text-zinc-400 max-w-2xl">
                  Architecture, intelligent engines, real-time live voice assistant, Google grounding, and DeepMind Science skill reference.
                </p>
              </div>

              {/* Section 1: Overview & Architecture */}
              <section className="space-y-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Cpu className="w-4 h-4 text-teal-400" />
                  <h3>1. System Architecture & High-Performance Full-Stack Setup</h3>
                </div>
                <p>
                  ASTRA AI runs as a production-grade full-stack Node.js 22 service mounted with an Express server and Vite React 19 SPA frontend. The server acts as a resilient gateway to the Google GenAI SDK (<code>@google/genai</code>), securing the API key server-side and streaming tokens to clients via Server-Sent Events (SSE).
                </p>
                <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 font-mono text-[11px] text-zinc-300 space-y-1">
                  <div className="text-teal-400 font-semibold">// Key Server Endpoints</div>
                  <div>POST /api/chat/stream          - Server-Sent Events chat streaming</div>
                  <div>POST /api/voice/speak          - Gemini 3.8 Flash-Lite 24kHz Neural TTS</div>
                  <div>WS   /api/live                 - Gemini 3.8 Live API 2-Way Voice WebSocket</div>
                  <div>POST /api/image/generate       - Gemini Nano Banana 2.1 Image Synthesis</div>
                  <div>GET  /api/science/pubchem      - PubChem chemical formula, CID & 2D diagram</div>
                  <div>GET  /api/science/uniprot      - UniProtKB protein sequence search</div>
                  <div>GET  /api/science/alphafold    - AlphaFold DB mmCIF/PDB & pLDDT confidence</div>
                  <div>GET  /api/science/pubmed       - NCBI PubMed peer-reviewed literature</div>
                </div>
              </section>

              {/* Section 2: Model Suite */}
              <section className="space-y-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <h3>2. Multi-Model Intelligent Suite</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
                    <span className="font-bold text-white text-xs block">ASTRA AI 3.8 Flash</span>
                    <span className="text-[10px] text-teal-400 font-mono">gemini-3.8-flash</span>
                    <p className="text-zinc-400 text-[11px]">
                      Default flagship for general reasoning, coding, and multimodal input.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
                    <span className="font-bold text-white text-xs block">ASTRA AI 3.5 Flash</span>
                    <span className="text-[10px] text-blue-400 font-mono">gemini-3.5-flash</span>
                    <p className="text-zinc-400 text-[11px]">
                      Optimized for real-time Google Search and Google Maps grounding tools.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
                    <span className="font-bold text-white text-xs block">ASTRA AI 3.1 Pro</span>
                    <span className="text-[10px] text-purple-400 font-mono">gemini-3.1-pro-preview</span>
                    <p className="text-zinc-400 text-[11px]">
                      Deep reasoning engine for complex mathematical proofs and architectural system design.
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-1">
                    <span className="font-bold text-white text-xs block">ASTRA AI Lite</span>
                    <span className="text-[10px] text-emerald-400 font-mono">gemini-3.1-flash-lite</span>
                    <p className="text-zinc-400 text-[11px]">
                      Ultra-low latency generation for instant answers, summaries, and chat titles.
                    </p>
                  </div>
                </div>
              </section>

              {/* Section 3: Voice Assistant */}
              <section className="space-y-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Mic className="w-4 h-4 text-emerald-400" />
                  <h3>3. Real-Time Live Voice Assistant & Neural Speech</h3>
                </div>
                <p>
                  The voice assistant provides live two-way spoken conversations using <code>gemini-3.8-live</code> over WebSockets (<code>/api/live</code>). It streams 16kHz PCM microphone audio from the user and receives 24kHz audio synthesis in real time with active speech interruption and live transcripts.
                </p>
                <p>
                  In addition, all assistant messages support Read Aloud using <code>gemini-3.8-flash-lite-tts</code> with a choice of 5 prebuilt voices (Natural, Kore, Puck, Fenrir, Charon).
                </p>
              </section>

              {/* Section 4: Science Workbench */}
              <section className="space-y-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Atom className="w-4 h-4 text-cyan-400" />
                  <h3>4. DeepMind Science Skills & Research Workbench</h3>
                </div>
                <p>
                  ASTRA AI adheres to DeepMind Science standards by verifying biological, chemical, and literature data through authoritative public repositories:
                </p>
                <ul className="list-disc list-inside space-y-1 text-zinc-400 text-[11px]">
                  <li><strong className="text-zinc-200">PubChem</strong>: Chemical formulas, weights, canonical SMILES, IUPAC names, and 2D chemical structure diagrams.</li>
                  <li><strong className="text-zinc-200">UniProtKB</strong>: Protein sequence annotations, organism lineages, and sequence lengths.</li>
                  <li><strong className="text-zinc-200">AlphaFold DB</strong>: 3D protein predictions, coordinate downloads (mmCIF/PDB), and 4-tier pLDDT confidence scores.</li>
                  <li><strong className="text-zinc-200">PubMed</strong>: Biomedical research citations and abstracts.</li>
                </ul>
              </section>

              {/* Section 5: Persistence */}
              <section className="space-y-3">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Database className="w-4 h-4 text-amber-400" />
                  <h3>5. Database & Cloud Firestore Persistence</h3>
                </div>
                <p>
                  User authentication is handled via Google Sign-In with Firebase Auth. Chat sessions and individual messages sync to Cloud Firestore under <code>/users/&#123;userId&#125;/sessions/&#123;sessionId&#125;</code> with hardened ABAC security rules (<code>firestore.rules</code>) and schema validation (<code>firebase-blueprint.json</code>).
                </p>
              </section>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <span className="text-[11px] text-zinc-400 font-mono text-center sm:text-left">
            {activeTab === 'college'
              ? `Report generated for ${studentName} (${rollNumber}) • ${collegeName}`
              : 'ASTRA AI Technical Documentation Manual • v2.0.0'}
          </span>
          <div className="flex items-center gap-2">
            {activeTab === 'college' ? (
              <button
                onClick={handleDownloadCollegePdf}
                disabled={isGeneratingPdf}
                type="button"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 font-bold text-xs cursor-pointer transition-all shadow-md shadow-teal-500/20 disabled:opacity-50"
              >
                {isGeneratingPdf ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>Download College Report PDF</span>
              </button>
            ) : (
              <button
                onClick={handleDownloadTechnicalPdf}
                disabled={isGeneratingPdf}
                type="button"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 font-bold text-xs cursor-pointer transition-all shadow-md shadow-teal-500/20 disabled:opacity-50"
              >
                {isGeneratingPdf ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                <span>Download System Manual PDF</span>
              </button>
            )}

            <button
              onClick={handlePrint}
              type="button"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-850 hover:bg-zinc-800 border border-zinc-750 text-zinc-200 font-semibold text-xs cursor-pointer transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              onClick={handleDownloadMarkdown}
              type="button"
              className="hidden md:flex items-center gap-1 px-3 py-2 rounded-xl bg-zinc-850 hover:bg-zinc-800 border border-zinc-750 text-zinc-300 text-xs cursor-pointer transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>.MD</span>
            </button>
            <button
              onClick={onClose}
              type="button"
              className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
