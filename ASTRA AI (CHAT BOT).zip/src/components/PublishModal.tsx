import React, { useState } from 'react';
import {
  X,
  Share2,
  Globe,
  Copy,
  Check,
  ExternalLink,
  UploadCloud,
  FileCode,
  Sparkles,
  Download,
  CheckCircle2,
  Send,
  Plus,
  Trash2,
  Eye,
  Layers,
} from 'lucide-react';
import { ChatSession } from '../types';

interface PublishModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSession?: ChatSession;
  onToast: (type: 'success' | 'info' | 'error', message: string) => void;
}

interface FormField {
  id: string;
  label: string;
  type: 'text' | 'textarea' | 'select' | 'rating';
  options?: string[];
  placeholder?: string;
  required?: boolean;
}

export const PublishModal: React.FC<PublishModalProps> = ({
  isOpen,
  onClose,
  currentSession,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'app' | 'chat' | 'form'>('form');
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);

  // Form Publisher State
  const [formTitle, setFormTitle] = useState('ASTRA AI Project Evaluation & Feedback Form');
  const [formDescription, setFormDescription] = useState(
    'Please review this college capstone project and provide your feedback or queries for ASTRA AI.'
  );
  const [formFields, setFormFields] = useState<FormField[]>([
    {
      id: 'f1',
      label: 'Evaluator / Student Name',
      type: 'text',
      placeholder: 'Enter full name',
      required: true,
    },
    {
      id: 'f2',
      label: 'Institution / College Name',
      type: 'text',
      placeholder: 'e.g. Department of Computer Science',
      required: true,
    },
    {
      id: 'f3',
      label: 'Project Usability & Intelligence Rating',
      type: 'rating',
      required: true,
    },
    {
      id: 'f4',
      label: 'Detailed Feedback or Questions for ASTRA AI',
      type: 'textarea',
      placeholder: 'Write your review or questions here...',
      required: false,
    },
  ]);
  const [isFormPublished, setIsFormPublished] = useState(false);
  const [publishedFormUrl, setPublishedFormUrl] = useState('');

  if (!isOpen) return null;

  const liveAppUrl = 'https://ais-pre-4wyxjocrvxswlhvcgw43yp-537979404969.asia-east1.run.app';

  const handleCopyLiveUrl = () => {
    navigator.clipboard.writeText(liveAppUrl);
    setCopiedLink(true);
    onToast('success', 'Published app URL copied to clipboard!');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCopyChatShareLink = () => {
    const url = `${window.location.origin}/#share=${currentSession?.id || 'astra'}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    onToast('success', 'Conversation share link copied!');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCopyEmbedCode = () => {
    const embed = `<iframe src="${liveAppUrl}" width="100%" height="700px" frameborder="0" allow="microphone" style="border-radius: 16px; border: 1px solid #27272a;"></iframe>`;
    navigator.clipboard.writeText(embed);
    setCopiedEmbed(true);
    onToast('success', 'Embed code copied to clipboard!');
    setTimeout(() => setCopiedEmbed(false), 2500);
  };

  const handlePublishForm = () => {
    const formId = `form_${Date.now()}`;
    const generatedUrl = `${window.location.origin}/#form=${formId}`;
    setPublishedFormUrl(generatedUrl);
    setIsFormPublished(true);
    onToast('success', 'Interactive Form published from ASTRA AI!');
  };

  const handleAddField = () => {
    const newField: FormField = {
      id: `f_${Date.now()}`,
      label: 'New Question',
      type: 'text',
      placeholder: 'Enter response...',
      required: false,
    };
    setFormFields([...formFields, newField]);
  };

  const handleRemoveField = (id: string) => {
    setFormFields(formFields.filter((f) => f.id !== id));
  };

  const handleExportFormHtml = () => {
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${formTitle} — Published from ASTRA AI</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen py-10 px-4 flex items-center justify-center font-sans">
  <div class="max-w-xl w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
    <div class="border-b border-zinc-800 pb-4">
      <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-300 text-xs font-semibold mb-2">
        <span>ASTRA AI Published Form</span>
      </div>
      <h1 class="text-2xl font-bold text-white">${formTitle}</h1>
      <p class="text-xs text-zinc-400 mt-1">${formDescription}</p>
    </div>

    <form onsubmit="event.preventDefault(); alert('Form submitted successfully to ASTRA AI!');" class="space-y-4">
      ${formFields
        .map(
          (field) => `
      <div class="space-y-1.5 text-left">
        <label class="block text-xs font-semibold text-zinc-300">
          ${field.label} ${field.required ? '<span class="text-teal-400">*</span>' : ''}
        </label>
        ${
          field.type === 'textarea'
            ? `<textarea rows="3" ${field.required ? 'required' : ''} placeholder="${field.placeholder || ''}" class="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-teal-500"></textarea>`
            : field.type === 'rating'
            ? `<select ${field.required ? 'required' : ''} class="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-teal-500">
                <option value="5">⭐⭐⭐⭐⭐ 5/5 — Outstanding</option>
                <option value="4">⭐⭐⭐⭐ 4/5 — Very Good</option>
                <option value="3">⭐⭐⭐ 3/5 — Satisfactory</option>
                <option value="2">⭐⭐ 2/5 — Needs Improvement</option>
               </select>`
            : `<input type="text" ${field.required ? 'required' : ''} placeholder="${field.placeholder || ''}" class="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:border-teal-500" />`
        }
      </div>`
        )
        .join('')}

      <button type="submit" class="w-full py-3 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 font-bold text-sm transition-colors cursor-pointer mt-4">
        Submit Response to ASTRA AI
      </button>
    </form>
    <div class="text-center text-[11px] text-zinc-500 pt-2 border-t border-zinc-800">
      Powered by ASTRA AI Next-Gen Intelligence
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `astra_ai_published_form_${Date.now()}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onToast('success', 'Standalone HTML Form downloaded!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl rounded-3xl bg-zinc-900 border border-zinc-750 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-zinc-800 bg-zinc-950/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-500 via-cyan-400 to-emerald-400 p-[1.5px] shadow-lg shadow-teal-500/20">
              <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center">
                <UploadCloud className="w-5 h-5 text-teal-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Publish from ASTRA AI</h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live Online
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Publish interactive forms, share conversations, or distribute your live app URL
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center px-5 pt-3 pb-2 border-b border-zinc-800 bg-zinc-950/50 gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('form')}
            type="button"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'form'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Publish Interactive Form</span>
          </button>
          <button
            onClick={() => setActiveTab('app')}
            type="button"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'app'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Published Live Web App</span>
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            type="button"
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-850'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Publish / Share Chat Session</span>
          </button>
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-xs text-zinc-300">
          {activeTab === 'form' && (
            /* TAB 1: FORM PUBLISHER */
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-teal-400" />
                    <h3 className="text-sm font-bold text-white">Create & Publish Custom Form</h3>
                  </div>
                  <span className="text-[10px] text-zinc-400">
                    Generate forms for reviews, feedback, or surveys
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] font-semibold text-zinc-300 block mb-1">
                      Form Title
                    </label>
                    <input
                      type="text"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-750 rounded-xl px-3 py-2 text-white text-xs focus:outline-hidden focus:border-teal-500 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-zinc-300 block mb-1">
                      Form Description / Subtitle
                    </label>
                    <input
                      type="text"
                      value={formDescription}
                      onChange={(e) => setFormDescription(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-750 rounded-xl px-3 py-2 text-zinc-300 text-xs focus:outline-hidden focus:border-teal-500"
                    />
                  </div>
                </div>
              </div>

              {/* Form Fields Editor */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Form Questions & Inputs ({formFields.length})
                  </span>
                  <button
                    onClick={handleAddField}
                    type="button"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-teal-300 text-xs font-semibold cursor-pointer transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Question</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {formFields.map((field, idx) => (
                    <div
                      key={field.id}
                      className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 flex items-start justify-between gap-3"
                    >
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono text-teal-400 font-bold">
                            Q{idx + 1}
                          </span>
                          <input
                            type="text"
                            value={field.label}
                            onChange={(e) => {
                              const updated = [...formFields];
                              updated[idx].label = e.target.value;
                              setFormFields(updated);
                            }}
                            className="flex-1 bg-zinc-900 border border-zinc-750 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-hidden focus:border-teal-500"
                          />
                          <select
                            value={field.type}
                            onChange={(e) => {
                              const updated = [...formFields];
                              updated[idx].type = e.target.value as FormField['type'];
                              setFormFields(updated);
                            }}
                            className="bg-zinc-900 border border-zinc-750 rounded-lg px-2 py-1 text-[11px] text-zinc-300 focus:outline-hidden"
                          >
                            <option value="text">Short Text</option>
                            <option value="textarea">Paragraph</option>
                            <option value="rating">Rating (1-5)</option>
                          </select>
                        </div>
                      </div>

                      <button
                        onClick={() => handleRemoveField(field.id)}
                        type="button"
                        className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                        title="Remove Question"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Publish Action & Outcomes */}
              <div className="pt-3 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePublishForm}
                    type="button"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 text-xs font-bold transition-all shadow-md shadow-teal-500/20 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Publish Form Online</span>
                  </button>

                  <button
                    onClick={handleExportFormHtml}
                    type="button"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Standalone HTML Form</span>
                  </button>
                </div>

                {isFormPublished && (
                  <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/20">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Form Published! Ready for submission.</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'app' && (
            /* TAB 2: LIVE WEB APP PUBLISHING */
            <div className="space-y-5">
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
                    <h3 className="text-sm font-bold text-white">Live Production App Deployment</h3>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                    Active & Operational
                  </span>
                </div>

                <p className="text-zinc-400 leading-relaxed text-xs">
                  Your ASTRA AI full-stack application is deployed to Google Cloud Run and accessible worldwide. Share this URL with your professors, classmates, or colleagues:
                </p>

                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 border border-zinc-750">
                  <input
                    type="text"
                    readOnly
                    value={liveAppUrl}
                    className="flex-1 bg-transparent text-teal-300 font-mono text-xs focus:outline-hidden select-all"
                  />
                  <button
                    onClick={handleCopyLiveUrl}
                    type="button"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-400 hover:bg-teal-300 text-zinc-950 text-xs font-bold transition-colors cursor-pointer"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
                  </button>
                  <a
                    href={liveAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
                    title="Open Live Application in new tab"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Embed In Website */}
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-cyan-400" />
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Embed ASTRA AI in another Webpage / Portal
                  </h4>
                </div>
                <p className="text-zinc-400 text-[11px]">
                  Copy this HTML snippet to embed ASTRA AI into your college portfolio, blog, or project website:
                </p>
                <div className="relative">
                  <pre className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 font-mono text-[11px] text-zinc-300 overflow-x-auto">
                    {`<iframe src="${liveAppUrl}" width="100%" height="700px" frameborder="0" allow="microphone" style="border-radius: 16px;"></iframe>`}
                  </pre>
                  <button
                    onClick={handleCopyEmbedCode}
                    type="button"
                    className="absolute right-2 top-2 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 transition-colors cursor-pointer flex items-center gap-1"
                  >
                    {copiedEmbed ? <Check className="w-3 h-3 text-teal-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedEmbed ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'chat' && (
            /* TAB 3: PUBLISH CHAT SESSION */
            <div className="space-y-5">
              <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
                <div className="flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-teal-400" />
                  <h3 className="text-sm font-bold text-white">Publish Conversation Thread</h3>
                </div>

                <p className="text-zinc-400 leading-relaxed text-xs">
                  Publish this active conversation: <strong>"{currentSession?.title || 'New Conversation'}"</strong> ({currentSession?.messages.length || 0} messages). Anyone with the link can view the formatted chat, code snippets, and research data.
                </p>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyChatShareLink}
                    type="button"
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 text-xs font-bold transition-all shadow-md shadow-teal-500/20 cursor-pointer"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Link Copied to Clipboard!' : 'Generate & Copy Share Link'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-zinc-500 font-mono">
            ASTRA AI • Publishing Gateway & Live Cloud Run
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
