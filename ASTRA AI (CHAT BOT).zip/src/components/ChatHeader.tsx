import React, { useState } from 'react';
import {
  PanelLeft,
  ChevronDown,
  Sparkles,
  Zap,
  HelpCircle,
  Plus,
  Atom,
  Globe,
  MapPin,
  Brain,
  Mic,
  Image as ImageIcon,
  LogIn,
  LogOut,
  User as UserIcon,
  Code2,
  Palette,
  GraduationCap,
  BookOpen,
  UploadCloud,
} from 'lucide-react';
import { AVAILABLE_MODELS, AVAILABLE_PERSONAS, GROUNDING_OPTIONS } from '../constants';
import { Persona } from '../types';
import { User as FirebaseUser } from 'firebase/auth';

interface ChatHeaderProps {
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  selectedModel: string;
  onSelectModel: (modelId: string) => void;
  selectedPersona: Persona;
  onSelectPersona: (persona: Persona) => void;
  groundingMode: string;
  onSelectGrounding: (mode: string) => void;
  onNewChat: () => void;
  onOpenVoice: () => void;
  onOpenVoicePanel: () => void;
  selectedVoice: string;
  onOpenImageGen: () => void;
  onOpenScience: () => void;
  onOpenInfo: () => void;
  onOpenDocs: () => void;
  onOpenPublish: () => void;
  user: FirebaseUser | null;
  onSignIn: () => void;
  onSignOut: () => void;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  isSidebarOpen,
  onToggleSidebar,
  selectedModel,
  onSelectModel,
  selectedPersona,
  onSelectPersona,
  groundingMode,
  onSelectGrounding,
  onNewChat,
  onOpenVoice,
  onOpenVoicePanel,
  selectedVoice,
  onOpenImageGen,
  onOpenScience,
  onOpenInfo,
  onOpenDocs,
  onOpenPublish,
  user,
  onSignIn,
  onSignOut,
}) => {
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [groundingDropdownOpen, setGroundingDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const currentModel =
    AVAILABLE_MODELS.find((m) => m.id === selectedModel) || AVAILABLE_MODELS[0];
  const currentGrounding =
    GROUNDING_OPTIONS.find((g) => g.id === groundingMode) || GROUNDING_OPTIONS[0];

  const getGroundingIcon = (id: string) => {
    switch (id) {
      case 'search':
        return <Globe className="w-3.5 h-3.5 text-blue-400" />;
      case 'maps':
        return <MapPin className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <Brain className="w-3.5 h-3.5 text-teal-400" />;
    }
  };

  return (
    <header className="h-14 border-b border-zinc-800/80 bg-zinc-950/85 backdrop-blur-md sticky top-0 z-20 flex items-center justify-between px-3 md:px-5">
      {/* Left controls */}
      <div className="flex items-center gap-1.5 md:gap-2.5">
        {!isSidebarOpen && (
          <button
            onClick={onToggleSidebar}
            title="Open sidebar"
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-850 transition-colors cursor-pointer"
          >
            <PanelLeft className="w-4 h-4" />
          </button>
        )}

        {/* Model dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setModelDropdownOpen(!modelDropdownOpen);
              setGroundingDropdownOpen(false);
              setUserDropdownOpen(false);
            }}
            type="button"
            className="flex items-center gap-1.5 md:gap-2 px-2.5 md:px-3 py-1.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 text-xs font-semibold text-zinc-100 transition-all cursor-pointer shadow-xs"
          >
            <div className="w-2 h-2 rounded-full bg-teal-400 shadow-xs shadow-teal-400/50" />
            <span className="truncate max-w-[110px] md:max-w-none">{currentModel.name}</span>
            <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
          </button>

          {modelDropdownOpen && (
            <>
              <div
                className="fixed inset-0 z-30"
                onClick={() => setModelDropdownOpen(false)}
              />
              <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-zinc-900 border border-zinc-750 shadow-2xl p-2 z-40 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                  Select Engine
                </div>
                <div className="space-y-1">
                  {AVAILABLE_MODELS.map((m) => {
                    const isSelected = m.id === selectedModel;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          onSelectModel(m.id);
                          setModelDropdownOpen(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-xl transition-all cursor-pointer flex flex-col gap-0.5 ${
                          isSelected
                            ? 'bg-teal-500/10 border border-teal-500/30 text-white'
                            : 'hover:bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-xs text-white">
                            {m.name}
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono ${
                              isSelected
                                ? 'bg-teal-500/20 text-teal-300'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {m.tag}
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-400 leading-snug">
                          {m.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Grounding dropdown (Search / Maps) */}
        <div className="relative hidden sm:block">
          <button
            onClick={() => {
              setGroundingDropdownOpen(!groundingDropdownOpen);
              setModelDropdownOpen(false);
              setUserDropdownOpen(false);
            }}
            type="button"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-zinc-900/60 hover:bg-zinc-850 border border-zinc-800 text-xs font-medium text-zinc-300 hover:text-white transition-all cursor-pointer"
          >
            {getGroundingIcon(groundingMode)}
            <span className="hidden md:inline">{currentGrounding.name}</span>
            <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
          </button>

          {groundingDropdownOpen && (
            <>
              <div
                className="fixed inset-0 z-30"
                onClick={() => setGroundingDropdownOpen(false)}
              />
              <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-zinc-900 border border-zinc-750 shadow-2xl p-2 z-40 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                  Grounding Sources
                </div>
                <div className="space-y-1">
                  {GROUNDING_OPTIONS.map((g) => {
                    const isSelected = g.id === groundingMode;
                    return (
                      <button
                        key={g.id}
                        type="button"
                        onClick={() => {
                          onSelectGrounding(g.id);
                          setGroundingDropdownOpen(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-xl transition-all cursor-pointer flex items-start gap-2.5 ${
                          isSelected
                            ? 'bg-teal-500/10 border border-teal-500/30 text-white'
                            : 'hover:bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        <div className="p-1 rounded-lg bg-zinc-800 mt-0.5">
                          {getGroundingIcon(g.id)}
                        </div>
                        <div>
                          <span className="font-semibold text-xs text-white block">
                            {g.name}
                          </span>
                          <span className="text-[11px] text-zinc-400 leading-snug">
                            {g.description}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Right features & user controls */}
      <div className="flex items-center gap-1.5 md:gap-2">
        {/* Voice Assistant Button */}
        <button
          onClick={onOpenVoice}
          type="button"
          title="Start live voice conversation"
          className="flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600/90 to-teal-600/90 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
        >
          <Mic className="w-3.5 h-3.5 animate-pulse" />
          <span className="hidden sm:inline">Voice Assistant</span>
        </button>

        {/* Create/Edit Image Button */}
        <button
          onClick={onOpenImageGen}
          type="button"
          title="Create & edit images with gemini-nano-banana-2.1"
          className="flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-200 text-xs font-semibold transition-all cursor-pointer"
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Image AI</span>
        </button>

        {/* Science Scout Button */}
        <button
          onClick={onOpenScience}
          type="button"
          title="DeepMind Science Scout (PubChem, UniProt, AlphaFold, PubMed)"
          className="flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-200 text-xs font-semibold transition-all cursor-pointer"
        >
          <Atom className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Science</span>
        </button>

        {/* Firebase Authentication (Google Sign-In) */}
        {user ? (
          <div className="relative">
            <button
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              type="button"
              className="flex items-center gap-1.5 p-1 rounded-xl hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'User'}
                  className="w-7 h-7 rounded-full border border-teal-400"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-teal-500/20 text-teal-300 flex items-center justify-center text-xs font-bold">
                  {user.displayName?.[0] || 'U'}
                </div>
              )}
            </button>

            {userDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-30"
                  onClick={() => setUserDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-zinc-900 border border-zinc-750 shadow-2xl p-2.5 z-40 animate-in fade-in zoom-in-95 duration-150 text-left">
                  <div className="px-2 py-1.5 border-b border-zinc-800 mb-1">
                    <p className="text-xs font-bold text-white truncate">
                      {user.displayName || 'Google Account'}
                    </p>
                    <p className="text-[11px] text-zinc-400 truncate">
                      {user.email}
                    </p>
                    <span className="inline-block mt-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded font-mono">
                      Cloud Sync Active
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      onSignOut();
                      setUserDropdownOpen(false);
                    }}
                    type="button"
                    className="w-full flex items-center gap-2 px-2.5 py-2 rounded-xl text-xs font-medium text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </>
            )}
          </div>
        ) : (
          <button
            onClick={onSignIn}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-750 text-xs font-semibold text-zinc-200 hover:text-white transition-all cursor-pointer"
          >
            <LogIn className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">Sign In</span>
          </button>
        )}

        {/* Publish / Share button */}
        <button
          onClick={onOpenPublish}
          type="button"
          title="Publish Form, Share Chat or View Live Web App"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-teal-500/10 hover:bg-teal-500/20 border border-teal-500/30 text-teal-300 text-xs font-semibold transition-all cursor-pointer shadow-xs"
        >
          <UploadCloud className="w-3.5 h-3.5 text-teal-400" />
          <span className="hidden md:inline">Publish</span>
        </button>

        {/* Documentation PDF button */}
        <button
          onClick={onOpenDocs}
          type="button"
          title="Open Documentation & Print to PDF"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-750 text-zinc-300 hover:text-white text-xs font-semibold transition-all cursor-pointer"
        >
          <BookOpen className="w-3.5 h-3.5 text-teal-400" />
          <span className="hidden lg:inline">Docs PDF</span>
        </button>

        {/* Info button */}
        <button
          onClick={onOpenInfo}
          type="button"
          title="About ASTRA AI"
          className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-850 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
