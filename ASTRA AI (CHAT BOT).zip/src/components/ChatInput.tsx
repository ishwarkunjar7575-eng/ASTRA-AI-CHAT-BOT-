import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowUp,
  Square,
  Paperclip,
  Mic,
  MicOff,
  X,
  Image as ImageIcon,
} from 'lucide-react';
import { ChatImage } from '../types';

interface ChatInputProps {
  onSendMessage: (text: string, image?: ChatImage) => void;
  onStopGeneration: () => void;
  isGenerating: boolean;
  disabled?: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onStopGeneration,
  isGenerating,
  disabled,
}) => {
  const [text, setText] = useState('');
  const [attachedImage, setAttachedImage] = useState<ChatImage | null>(null);
  const [isListening, setIsListening] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(textareaRef.current.scrollHeight, 200);
      textareaRef.current.style.height = `${newHeight}px`;
    }
  }, [text]);

  // Handle clipboard paste of images
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      if (!e.clipboardData) return;
      const items = e.clipboardData.items;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith('image/')) {
          const file = items[i].getAsFile();
          if (file) {
            processImageFile(file);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  const processImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      console.warn('Selected file is not an image');
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      console.warn('Image file exceeds 20MB limit');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Extract base64 part
      const base64Data = result.split(',')[1];
      setAttachedImage({
        mimeType: file.type,
        data: base64Data,
        previewUrl: result,
        name: file.name,
        size: file.size,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      processImageFile(files[0]);
    }
    // reset input
    e.target.value = '';
  };

  const handleToggleListening = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript) {
          setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        }
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    if (isGenerating) return;
    const trimmed = text.trim();
    if (!trimmed && !attachedImage) return;

    onSendMessage(trimmed, attachedImage || undefined);
    setText('');
    setAttachedImage(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 pb-4">
      {/* Container box */}
      <div className="relative rounded-2xl bg-zinc-900 border border-zinc-750/90 shadow-xl focus-within:border-teal-500/70 focus-within:ring-1 focus-within:ring-teal-500/30 transition-all">
        {/* Attached image preview */}
        {attachedImage && (
          <div className="p-3 border-b border-zinc-800 flex items-center gap-3">
            <div className="relative rounded-lg overflow-hidden border border-zinc-700 bg-zinc-950 w-14 h-14 shrink-0">
              <img
                src={attachedImage.previewUrl}
                alt="Thumbnail"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => setAttachedImage(null)}
                className="absolute top-1 right-1 p-0.5 rounded-full bg-black/80 text-white hover:bg-red-500 transition-colors"
                title="Remove image"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-medium text-zinc-200 truncate max-w-xs">
                {attachedImage.name || 'Pasted image'}
              </span>
              <span className="text-[11px] text-zinc-400">
                {attachedImage.size
                  ? `${Math.round(attachedImage.size / 1024)} KB`
                  : 'Image attachment ready'}
              </span>
            </div>
          </div>
        )}

        {/* Text area */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            attachedImage
              ? 'Ask anything about this image...'
              : 'Message ASTRA AI... (or paste an image, press Enter to send)'
          }
          rows={1}
          disabled={disabled}
          className="w-full bg-transparent text-[15px] text-zinc-100 placeholder-zinc-400 px-4 pt-3.5 pb-2 resize-none focus:outline-hidden min-h-[44px] max-h-[200px] leading-relaxed"
        />

        {/* Bottom controls row */}
        <div className="flex items-center justify-between px-3 pb-2.5 pt-1">
          <div className="flex items-center gap-1">
            {/* Image upload button */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/png,image/jpeg,image/webp,image/gif"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Attach image"
              className="p-2 rounded-xl text-zinc-400 hover:text-teal-300 hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Voice Dictation button */}
            <button
              type="button"
              onClick={handleToggleListening}
              title={isListening ? 'Stop recording voice' : 'Dictate with voice'}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                isListening
                  ? 'bg-red-500/20 text-red-400 animate-pulse'
                  : 'text-zinc-400 hover:text-teal-300 hover:bg-zinc-800'
              }`}
            >
              {isListening ? (
                <MicOff className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Submit / Stop button */}
            {isGenerating ? (
              <button
                type="button"
                onClick={onStopGeneration}
                title="Stop generating"
                className="flex items-center justify-center w-8 h-8 rounded-xl bg-zinc-200 hover:bg-white text-zinc-950 font-semibold shadow-md transition-all cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={(!text.trim() && !attachedImage) || disabled}
                title="Send message"
                className={`flex items-center justify-center w-8 h-8 rounded-xl transition-all cursor-pointer ${
                  text.trim() || attachedImage
                    ? 'bg-teal-400 hover:bg-teal-300 text-zinc-950 shadow-md shadow-teal-500/20'
                    : 'bg-zinc-800 text-zinc-400 cursor-not-allowed opacity-60'
                }`}
              >
                <ArrowUp className="w-4 h-4 stroke-[2.5]" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="text-center mt-2 text-[11px] text-zinc-300 select-none">
        ASTRA AI can make mistakes. Verify important information before reliance.
      </div>
    </div>
  );
};
