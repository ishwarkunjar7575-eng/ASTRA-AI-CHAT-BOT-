import React, { useState, useRef } from 'react';
import {
  X,
  Image as ImageIcon,
  Sparkles,
  Download,
  Send,
  Loader2,
  Paperclip,
  Trash2,
} from 'lucide-react';
import { ChatImage } from '../types';

interface ImageGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertToChat: (imageUrl: string, prompt: string) => void;
}

export const ImageGeneratorModal: React.FC<ImageGeneratorModalProps> = ({
  isOpen,
  onClose,
  onInsertToChat,
}) => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [referenceImage, setReferenceImage] = useState<ChatImage | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(',')[1];
      setReferenceImage({
        mimeType: file.type,
        data: base64Data,
        previewUrl: result,
        name: file.name,
      });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setErrorText(null);

    try {
      const response = await fetch('/api/image/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspectRatio,
          base64Image: referenceImage?.data,
          mimeType: referenceImage?.mimeType,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate image.');
      }

      setGeneratedImageUrl(data.imageUrl);
    } catch (err) {
      console.error('Image generation failed:', err);
      setErrorText(
        err instanceof Error ? err.message : 'Image generation failed.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!generatedImageUrl) return;
    const a = document.createElement('a');
    a.href = generatedImageUrl;
    a.download = `astra_ai_image_${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleInsert = () => {
    if (!generatedImageUrl) return;
    onInsertToChat(generatedImageUrl, prompt);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl rounded-3xl bg-zinc-900 border border-zinc-750 shadow-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-500 via-pink-500 to-amber-400 p-[1.5px]">
              <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                <ImageIcon className="w-4 h-4 text-pink-300" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Create & Edit Images
              </h2>
              <p className="text-xs text-zinc-400">
                Powered by gemini-nano-banana-2.1
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input prompt */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
            Image Prompt
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to create or how you'd like to edit the uploaded image..."
            rows={3}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-hidden focus:border-pink-500/70 transition-all resize-none"
          />
        </div>

        {/* Aspect Ratio Selection */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
            Aspect Ratio
          </label>
          <div className="flex items-center gap-2">
            {['1:1', '16:9', '9:16', '4:3', '3:4'].map((ratio) => (
              <button
                key={ratio}
                type="button"
                onClick={() => setAspectRatio(ratio)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  aspectRatio === ratio
                    ? 'bg-pink-500/20 border border-pink-500/60 text-pink-200'
                    : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                {ratio}
              </button>
            ))}
          </div>
        </div>

        {/* Optional reference image for editing */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
              Edit Existing Image (Optional)
            </span>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            {!referenceImage ? (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 text-xs text-pink-400 hover:text-pink-300 cursor-pointer"
              >
                <Paperclip className="w-3.5 h-3.5" />
                <span>Upload source image</span>
              </button>
            ) : null}
          </div>

          {referenceImage && (
            <div className="flex items-center gap-3 p-2.5 rounded-xl bg-zinc-950 border border-zinc-800">
              <img
                src={referenceImage.previewUrl}
                alt="Source preview"
                className="w-12 h-12 object-cover rounded-lg border border-zinc-700"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-zinc-200 truncate font-medium">
                  {referenceImage.name}
                </p>
                <p className="text-[11px] text-zinc-400">
                  Ready to edit with prompt instructions
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReferenceImage(null)}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-red-400 hover:bg-zinc-800 cursor-pointer"
                title="Remove image"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Error banner */}
        {errorText && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800 text-red-200 text-xs">
            {errorText}
          </div>
        )}

        {/* Generated Image Preview Area */}
        {generatedImageUrl && (
          <div className="space-y-3 pt-2">
            <div className="relative rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950 max-h-80 flex items-center justify-center">
              <img
                src={generatedImageUrl}
                alt="Generated output"
                className="max-h-80 w-auto object-contain rounded-xl"
              />
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={handleDownload}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white cursor-pointer transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
              <button
                type="button"
                onClick={handleInsert}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-pink-500 hover:bg-pink-400 text-white text-xs font-semibold cursor-pointer transition-colors shadow-sm"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Insert to Chat</span>
              </button>
            </div>
          </div>
        )}

        {/* Generate Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm transition-all cursor-pointer ${
              !prompt.trim() || isGenerating
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white shadow-lg shadow-pink-500/20'
            }`}
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Generating with Gemini Nano Banana...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>
                  {referenceImage ? 'Edit Image' : 'Generate Image'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
