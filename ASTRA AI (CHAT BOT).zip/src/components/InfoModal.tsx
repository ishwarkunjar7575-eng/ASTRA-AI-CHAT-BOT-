import React from 'react';
import { X, Sparkles, Command, Shield, Cpu, MessageSquare } from 'lucide-react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDocs?: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose, onOpenDocs }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="fixed inset-0"
        onClick={onClose}
      />
      <div className="relative w-full max-w-lg rounded-2xl bg-zinc-900 border border-zinc-750 shadow-2xl p-6 z-10 text-left space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 p-[1.5px]">
              <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-teal-300" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-white">About ASTRA AI</h2>
              <p className="text-xs text-zinc-400">Next-gen multimodal intelligence</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content sections */}
        <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
          <div className="flex gap-3 items-start">
            <div className="p-2 rounded-lg bg-teal-500/10 text-teal-300 shrink-0">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-white mb-0.5">High-Speed Engine</h4>
              <p>
                Powered by Gemini models via Google GenAI SDK with real-time token streaming and low-latency response generation.
              </p>
            </div>
          </div>

          <div className="flex gap-3 items-start">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-300 shrink-0">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-white mb-0.5">Customizable Personas</h4>
              <p>
                Switch between Software Architect, Creative Thinker, Socratic Tutor, Concise & Direct, and Balanced Assistant to fit your current workflow.
              </p>
            </div>
          </div>

          <div className="flex gap-3 items-start">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-300 shrink-0">
              <Command className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-white mb-0.5">Multimodal & Audio</h4>
              <p>
                Upload images or diagrams for instant computer vision analysis. Dictate prompts using voice speech-to-text, or listen to responses with built-in voice playback.
              </p>
            </div>
          </div>

          <div className="flex gap-3 items-start">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-300 shrink-0">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-semibold text-white mb-0.5">Local Storage & Privacy</h4>
              <p>
                Your conversation history is stored strictly in your browser&apos;s local storage. You can export conversations to Markdown or clear all history at any time.
              </p>
            </div>
          </div>
        </div>

        {/* Keyboard Shortcuts */}
        <div className="pt-2 border-t border-zinc-800">
          <h4 className="font-semibold text-xs text-white mb-2 uppercase tracking-wider text-zinc-400">
            Keyboard Shortcuts
          </h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-zinc-800">
              <span className="text-zinc-400">Send message</span>
              <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300">
                Enter
              </kbd>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-zinc-800">
              <span className="text-zinc-400">New line</span>
              <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300">
                Shift + Enter
              </kbd>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-zinc-800">
              <span className="text-zinc-400">New Chat</span>
              <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300">
                Ctrl + K
              </kbd>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-zinc-800">
              <span className="text-zinc-400">Paste image</span>
              <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300">
                Ctrl + V
              </kbd>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 flex items-center justify-between">
          {onOpenDocs ? (
            <button
              onClick={() => {
                onClose();
                onOpenDocs();
              }}
              type="button"
              className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-teal-300 font-semibold text-xs cursor-pointer transition-colors"
            >
              Open Documentation & PDF Manual
            </button>
          ) : <div />}
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-teal-400 hover:bg-teal-300 text-zinc-950 font-semibold text-xs cursor-pointer transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
