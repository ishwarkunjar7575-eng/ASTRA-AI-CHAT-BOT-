import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatHeader } from './components/ChatHeader';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { WelcomeScreen } from './components/WelcomeScreen';
import { InfoModal } from './components/InfoModal';
import { DocumentationModal } from './components/DocumentationModal';
import { PublishModal } from './components/PublishModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { VoiceConversationModal } from './components/VoiceConversationModal';
import { VoiceAssistantPanel } from './components/VoiceAssistantPanel';
import { ImageGeneratorModal } from './components/ImageGeneratorModal';
import { ScienceWorkbench } from './components/ScienceWorkbench';
import { ChatSession, Message, ChatImage, Persona } from './types';
import {
  STORAGE_KEYS,
  AVAILABLE_MODELS,
  AVAILABLE_PERSONAS,
  VOICE_OPTIONS,
} from './constants';
import {
  auth,
  db,
  subscribeToAuth,
  signInWithGoogle,
  signOutUser,
  testConnection,
  handleFirestoreError,
  OperationType,
} from './firebase';
import { User as FirebaseUser } from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  getDocs,
} from 'firebase/firestore';

export default function App() {
  // Auth state
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);

  // Chat sessions state
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved =
        localStorage.getItem(STORAGE_KEYS.SESSIONS) ||
        localStorage.getItem('chatxyz_sessions');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse sessions from localStorage:', e);
    }
    return [];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string | null>(() => {
    try {
      return (
        localStorage.getItem(STORAGE_KEYS.CURRENT_SESSION_ID) ||
        localStorage.getItem('chatxyz_current_session_id') ||
        null
      );
    } catch {
      return null;
    }
  });

  const [selectedModel, setSelectedModel] = useState<string>(() => {
    try {
      return (
        localStorage.getItem(STORAGE_KEYS.SELECTED_MODEL) ||
        localStorage.getItem('chatxyz_selected_model') ||
        AVAILABLE_MODELS[0].id
      );
    } catch {
      return AVAILABLE_MODELS[0].id;
    }
  });

  const [selectedPersona, setSelectedPersona] = useState<Persona>(() => {
    try {
      const savedId =
        localStorage.getItem(STORAGE_KEYS.SELECTED_PERSONA) ||
        localStorage.getItem('chatxyz_selected_persona');
      const found = AVAILABLE_PERSONAS.find((p) => p.id === savedId);
      return found || AVAILABLE_PERSONAS[0];
    } catch {
      return AVAILABLE_PERSONAS[0];
    }
  });

  const [groundingMode, setGroundingMode] = useState<string>(() => {
    try {
      return (
        localStorage.getItem(STORAGE_KEYS.GROUNDING_MODE) ||
        localStorage.getItem('chatxyz_grounding_mode') ||
        'none'
      );
    } catch {
      return 'none';
    }
  });

  const [selectedVoice, setSelectedVoice] = useState<string>(() => {
    try {
      return (
        localStorage.getItem(STORAGE_KEYS.SELECTED_VOICE) ||
        localStorage.getItem('chatxyz_selected_voice') ||
        VOICE_OPTIONS[0].id
      );
    } catch {
      return 'Zephyr';
    }
  });

  const [autoSpeak, setAutoSpeak] = useState<boolean>(() => {
    try {
      return (
        localStorage.getItem('astra_ai_auto_speak') === 'true' ||
        localStorage.getItem('chatxyz_auto_speak') === 'true'
      );
    } catch {
      return false;
    }
  });

  // UI Modals
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isVoicePanelOpen, setIsVoicePanelOpen] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [isScienceModalOpen, setIsScienceModalOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Helper toast notification
  const addToast = (type: 'success' | 'error' | 'info', text: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  // 1. Firebase setup & connection check on initial boot
  useEffect(() => {
    testConnection();
    const unsubscribe = subscribeToAuth((user) => {
      setCurrentUser(user);
      if (user) {
        addToast('success', `Signed in as ${user.displayName || user.email}`);
      }
    });
    return () => unsubscribe();
  }, []);

  // 2. Firestore Cloud Sync for authenticated users
  useEffect(() => {
    if (!currentUser) return;

    const sessionsPath = `users/${currentUser.uid}/sessions`;
    const sessionsCol = collection(db, 'users', currentUser.uid, 'sessions');
    const q = query(sessionsCol, orderBy('updatedAt', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      async (snapshot) => {
        const loadedSessions: ChatSession[] = [];
        for (const docSnap of snapshot.docs) {
          const sessionData = docSnap.data();

          // Load messages for session
          const messagesCol = collection(
            db,
            'users',
            currentUser.uid,
            'sessions',
            docSnap.id,
            'messages'
          );
          const messagesSnap = await getDocs(
            query(messagesCol, orderBy('timestamp', 'asc'))
          );
          const sessionMessages: Message[] = messagesSnap.docs.map(
            (m) => m.data() as Message
          );

          loadedSessions.push({
            id: docSnap.id,
            title: sessionData.title || 'New Conversation',
            createdAt: sessionData.createdAt || Date.now(),
            updatedAt: sessionData.updatedAt || Date.now(),
            messages: sessionMessages,
            model: sessionData.model || selectedModel,
            personaId: sessionData.personaId || selectedPersona.id,
          });
        }

        if (loadedSessions.length > 0) {
          setSessions(loadedSessions);
          if (!currentSessionId || !loadedSessions.find((s) => s.id === currentSessionId)) {
            setCurrentSessionId(loadedSessions[0].id);
          }
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, sessionsPath);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // Sync to local storage as offline mirror
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
    } catch (e) {
      console.error('Failed to save sessions to localStorage:', e);
    }
  }, [sessions]);

  useEffect(() => {
    if (currentSessionId) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_SESSION_ID, currentSessionId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_SESSION_ID);
    }
  }, [currentSessionId]);

  const handleSelectModel = (modelId: string) => {
    setSelectedModel(modelId);
    localStorage.setItem(STORAGE_KEYS.SELECTED_MODEL, modelId);
  };

  const handleSelectPersona = (persona: Persona) => {
    setSelectedPersona(persona);
    localStorage.setItem(STORAGE_KEYS.SELECTED_PERSONA, persona.id);
  };

  const handleSelectGrounding = (mode: string) => {
    setGroundingMode(mode);
    localStorage.setItem(STORAGE_KEYS.GROUNDING_MODE, mode);
    addToast('info', `Grounding mode: ${mode.toUpperCase()}`);
  };

  const handleSelectVoice = (voice: string) => {
    setSelectedVoice(voice);
    localStorage.setItem(STORAGE_KEYS.SELECTED_VOICE, voice);
    addToast('success', `Voice changed to ${voice}`);
  };

  const handleToggleAutoSpeak = (enabled: boolean) => {
    setAutoSpeak(enabled);
    localStorage.setItem('astra_ai_auto_speak', String(enabled));
    addToast('info', enabled ? 'Auto-Read enabled' : 'Auto-Read disabled');
  };

  const currentSession = sessions.find((s) => s.id === currentSessionId);
  const messages = currentSession?.messages || [];

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, []);

  useEffect(() => {
    scrollToBottom('auto');
  }, [currentSessionId]);

  // Keyboard shortcut Ctrl+K / Cmd+K for new chat
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        handleNewChat();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Responsive sidebar
  useEffect(() => {
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  }, []);

  // Helper to persist session to Firestore
  const saveSessionToCloud = async (session: ChatSession) => {
    if (!currentUser) return;
    try {
      const sessionRef = doc(db, 'users', currentUser.uid, 'sessions', session.id);
      await setDoc(
        sessionRef,
        {
          id: session.id,
          userId: currentUser.uid,
          title: session.title,
          model: session.model,
          personaId: session.personaId,
          createdAt: session.createdAt,
          updatedAt: session.updatedAt,
        },
        { merge: true }
      );
    } catch (err) {
      console.error('Failed to sync session to Firestore:', err);
    }
  };

  const saveMessageToCloud = async (sessionId: string, message: Message) => {
    if (!currentUser) return;
    try {
      const msgRef = doc(
        db,
        'users',
        currentUser.uid,
        'sessions',
        sessionId,
        'messages',
        message.id
      );
      await setDoc(msgRef, {
        id: message.id,
        userId: currentUser.uid,
        sessionId,
        role: message.role,
        text: message.text || '',
        timestamp: message.timestamp,
        feedback: message.feedback || null,
        imageUrl: message.image?.previewUrl || null,
      });
    } catch (err) {
      console.error('Failed to sync message to Firestore:', err);
    }
  };

  // Create new chat
  const handleNewChat = () => {
    if (isGenerating) {
      handleStopGeneration();
    }
    const newSessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newSession: ChatSession = {
      id: newSessionId,
      title: 'New Conversation',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      model: selectedModel,
      personaId: selectedPersona.id,
    };
    setSessions((prev) => [newSession, ...prev]);
    setCurrentSessionId(newSessionId);
    saveSessionToCloud(newSession);
  };

  // Delete session
  const handleDeleteSession = async (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (currentSessionId === id) {
      const remaining = sessions.filter((s) => s.id !== id);
      setCurrentSessionId(remaining.length > 0 ? remaining[0].id : null);
    }

    if (currentUser) {
      try {
        const sessionRef = doc(db, 'users', currentUser.uid, 'sessions', id);
        await deleteDoc(sessionRef);
      } catch (err) {
        console.error('Error deleting session from Firestore:', err);
      }
    }

    addToast('info', 'Conversation deleted');
  };

  // Rename session
  const handleRenameSession = async (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s))
    );
    if (currentUser) {
      try {
        const sessionRef = doc(db, 'users', currentUser.uid, 'sessions', id);
        await setDoc(sessionRef, { title: newTitle, updatedAt: Date.now() }, { merge: true });
      } catch (err) {
        console.error('Error renaming in Firestore:', err);
      }
    }
    addToast('success', 'Conversation renamed');
  };

  // Clear all sessions
  const handleClearAllSessions = async () => {
    if (window.confirm('Are you sure you want to delete all conversations? This cannot be undone.')) {
      if (currentUser) {
        for (const s of sessions) {
          try {
            await deleteDoc(doc(db, 'users', currentUser.uid, 'sessions', s.id));
          } catch (e) {}
        }
      }
      setSessions([]);
      setCurrentSessionId(null);
      addToast('info', 'All conversations cleared');
    }
  };

  // Export session to Markdown
  const handleExportSession = (session: ChatSession) => {
    const dateStr = new Date(session.createdAt).toLocaleDateString();
    let md = `# ${session.title}\n*Exported from ASTRA AI on ${dateStr}*\n\n---\n\n`;

    session.messages.forEach((msg) => {
      const sender = msg.role === 'model' ? 'ASTRA AI' : 'User';
      const time = new Date(msg.timestamp).toLocaleTimeString();
      md += `### ${sender} (${time})\n\n`;
      if (msg.image?.name) {
        md += `*[Attached Image: ${msg.image.name}]*\n\n`;
      }
      md += `${msg.text}\n\n---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${session.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    addToast('success', 'Chat exported as Markdown');
  };

  // Stop generation
  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);

    if (currentSessionId) {
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== currentSessionId) return s;
          const updatedMessages = s.messages.map((m, idx) => {
            if (idx === s.messages.length - 1 && m.isStreaming) {
              return { ...m, isStreaming: false };
            }
            return m;
          });
          return { ...s, messages: updatedMessages };
        })
      );
    }
  };

  // Stream AI response helper
  const streamAIResponse = async (
    targetSessionId: string,
    historyMessages: Message[],
    isFirstExchange: boolean,
    firstPrompt: string
  ) => {
    const modelMsgId = `msg_${Date.now()}_model`;
    const newModelMsg: Message = {
      id: modelMsgId,
      role: 'model',
      text: '',
      timestamp: Date.now(),
      isStreaming: true,
    };

    setSessions((prev) =>
      prev.map((s) => {
        if (s.id !== targetSessionId) return s;
        return {
          ...s,
          updatedAt: Date.now(),
          messages: [...s.messages, newModelMsg],
        };
      })
    );

    setIsGenerating(true);
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const payloadMessages = historyMessages.map((msg) => {
        const parts: any[] = [];
        if (msg.image) {
          parts.push({
            inlineData: {
              mimeType: msg.image.mimeType,
              data: msg.image.data,
            },
          });
        }
        if (msg.text) {
          parts.push({ text: msg.text });
        }
        return {
          role: msg.role === 'model' ? 'model' : 'user',
          parts,
        };
      });

      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: payloadMessages,
          model: selectedModel,
          grounding: groundingMode,
          systemInstruction: selectedPersona.systemInstruction,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('Response body stream is not readable.');

      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;

          const dataContent = trimmed.substring(5).trim();
          if (dataContent === '[DONE]') {
            break;
          }

          try {
            const parsed = JSON.parse(dataContent);
            if (parsed.error) {
              throw new Error(parsed.error);
            }
            if (parsed.text) {
              accumulatedText += parsed.text;
              setSessions((prev) =>
                prev.map((s) => {
                  if (s.id !== targetSessionId) return s;
                  const updated = s.messages.map((m) =>
                    m.id === modelMsgId
                      ? { ...m, text: accumulatedText, isStreaming: true }
                      : m
                  );
                  return { ...s, messages: updated };
                })
              );
              scrollToBottom('smooth');
            }
          } catch (jsonErr) {}
        }
      }

      // Finalize model message
      const finalMsg: Message = {
        id: modelMsgId,
        role: 'model',
        text: accumulatedText,
        timestamp: Date.now(),
        isStreaming: false,
      };

      setSessions((prev) =>
        prev.map((s) => {
          if (s.id !== targetSessionId) return s;
          const updated = s.messages.map((m) =>
            m.id === modelMsgId ? finalMsg : m
          );
          return { ...s, messages: updated, updatedAt: Date.now() };
        })
      );

      // Save to Cloud Firestore
      saveMessageToCloud(targetSessionId, finalMsg);

      // Auto-Read aloud if enabled
      if (autoSpeak && accumulatedText) {
        fetch('/api/voice/speak', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: accumulatedText,
            voiceName: selectedVoice,
          }),
        })
          .then((res) => res.json())
          .then((data) => {
            if (data?.audio) {
              const audio = new Audio(`data:audio/wav;base64,${data.audio}`);
              audio.play().catch(() => {});
            }
          })
          .catch(() => {});
      }

      // Generate title if first exchange
      if (isFirstExchange && firstPrompt) {
        fetch('/api/chat/generate-title', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: firstPrompt }),
        })
          .then((res) => res.json())
          .then((data) => {
            if (data?.title) {
              setSessions((prev) =>
                prev.map((s) =>
                  s.id === targetSessionId ? { ...s, title: data.title } : s
                )
              );
              const target = sessions.find((s) => s.id === targetSessionId);
              if (target) {
                saveSessionToCloud({ ...target, title: data.title });
              }
            }
          })
          .catch((err) => console.error('Title generation failed:', err));
      }
    } catch (err: unknown) {
      if ((err as Error)?.name === 'AbortError') {
        console.log('Generation aborted by user.');
      } else {
        const errorMsg =
          err instanceof Error
            ? err.message
            : 'An unexpected generation error occurred.';
        console.error('Streaming error:', errorMsg);

        setSessions((prev) =>
          prev.map((s) => {
            if (s.id !== targetSessionId) return s;
            const updated = s.messages.map((m) =>
              m.id === modelMsgId
                ? {
                    ...m,
                    isStreaming: false,
                    error: errorMsg,
                  }
                : m
            );
            return { ...s, messages: updated };
          })
        );
        addToast('error', errorMsg);
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  // Send message
  const handleSendMessage = (text: string, image?: ChatImage) => {
    let targetId = currentSessionId;
    let isFirst = false;

    if (!targetId || !sessions.find((s) => s.id === targetId)) {
      targetId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const newSession: ChatSession = {
        id: targetId,
        title: text.slice(0, 30) || 'Query',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        model: selectedModel,
        personaId: selectedPersona.id,
      };
      setSessions((prev) => [newSession, ...prev]);
      setCurrentSessionId(targetId);
      saveSessionToCloud(newSession);
      isFirst = true;
    } else {
      const active = sessions.find((s) => s.id === targetId);
      if (active && active.messages.length === 0) {
        isFirst = true;
      }
    }

    const userMessage: Message = {
      id: `msg_${Date.now()}_user`,
      role: 'user',
      text,
      image,
      timestamp: Date.now(),
    };

    const currentMessages =
      sessions.find((s) => s.id === targetId)?.messages || [];
    const updatedMessages = [...currentMessages, userMessage];

    setSessions((prev) =>
      prev.map((s) =>
        s.id === targetId
          ? { ...s, updatedAt: Date.now(), messages: updatedMessages }
          : s
      )
    );

    saveMessageToCloud(targetId, userMessage);
    setTimeout(() => scrollToBottom('smooth'), 50);

    streamAIResponse(targetId, updatedMessages, isFirst, text);
  };

  // Insert generated image directly into chat
  const handleInsertGeneratedImage = (imageUrl: string, prompt: string) => {
    const base64Data = imageUrl.split(',')[1] || '';
    const chatImg: ChatImage = {
      mimeType: 'image/png',
      data: base64Data,
      previewUrl: imageUrl,
      name: `Generated: ${prompt.slice(0, 25)}...`,
    };
    handleSendMessage(`Created with gemini-nano-banana-2.1: "${prompt}"`, chatImg);
  };

  // Google sign in / sign out
  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (err) {
      console.error('Sign in failed:', err);
      addToast('error', 'Google Sign-In was cancelled or failed.');
    }
  };

  const handleGoogleSignOut = async () => {
    try {
      await signOutUser();
      addToast('info', 'Signed out successfully');
    } catch (err) {
      console.error('Sign out failed:', err);
    }
  };

  // Regenerate
  const handleRegenerate = () => {
    if (isGenerating || !currentSession || messages.length === 0) return;

    const lastUserIndex = [...messages]
      .reverse()
      .findIndex((m) => m.role === 'user');
    if (lastUserIndex === -1) return;

    const actualUserIndex = messages.length - 1 - lastUserIndex;
    const historyUpToUser = messages.slice(0, actualUserIndex + 1);

    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSession.id
          ? { ...s, messages: historyUpToUser, updatedAt: Date.now() }
          : s
      )
    );

    const userMsg = messages[actualUserIndex];
    streamAIResponse(
      currentSession.id,
      historyUpToUser,
      false,
      userMsg.text
    );
  };

  // Feedback
  const handleFeedback = (messageId: string, type: 'like' | 'dislike') => {
    if (!currentSessionId) return;
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id !== currentSessionId) return s;
        const updated = s.messages.map((m) => {
          if (m.id === messageId) {
            return {
              ...m,
              feedback: m.feedback === type ? null : type,
            };
          }
          return m;
        });
        return { ...s, messages: updated };
      })
    );
    addToast('success', type === 'like' ? 'Marked as helpful' : 'Feedback recorded');
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-zinc-950 text-zinc-100 font-sans">
      {/* Toast notifications */}
      <ToastContainer
        toasts={toasts}
        onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))}
      />

      {/* Info Modal */}
      <InfoModal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
        onOpenDocs={() => setIsDocModalOpen(true)}
      />

      {/* Technical Documentation & PDF Manual Modal */}
      <DocumentationModal
        isOpen={isDocModalOpen}
        onClose={() => setIsDocModalOpen(false)}
      />

      {/* Publish & Share from ASTRA AI Modal */}
      <PublishModal
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        currentSession={currentSession}
        onToast={addToast}
      />

      {/* Gemini 3.8 Live Voice Call Modal */}
      <VoiceConversationModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        selectedVoice={selectedVoice}
        onSelectVoice={handleSelectVoice}
      />

      {/* Voice Assistant Persona & Controls Panel */}
      <VoiceAssistantPanel
        isOpen={isVoicePanelOpen}
        onClose={() => setIsVoicePanelOpen(false)}
        selectedVoice={selectedVoice}
        onSelectVoice={handleSelectVoice}
        onStartLiveCall={() => setIsVoiceModalOpen(true)}
        autoSpeak={autoSpeak}
        onToggleAutoSpeak={handleToggleAutoSpeak}
      />

      {/* Image AI Generator & Editor Modal */}
      <ImageGeneratorModal
        isOpen={isImageModalOpen}
        onClose={() => setIsImageModalOpen(false)}
        onInsertToChat={handleInsertGeneratedImage}
      />

      {/* DeepMind Science Skills Workbench */}
      <ScienceWorkbench
        isOpen={isScienceModalOpen}
        onClose={() => setIsScienceModalOpen(false)}
        onSendToChat={(query) => handleSendMessage(query)}
      />

      {/* Floating Voice Assistant Trigger */}
      <button
        type="button"
        onClick={() => setIsVoicePanelOpen(true)}
        className="fixed bottom-24 right-4 md:right-6 z-20 flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-zinc-900/95 hover:bg-zinc-850 border border-teal-500/50 hover:border-teal-400 text-teal-300 hover:text-white shadow-xl shadow-teal-500/10 text-xs font-semibold backdrop-blur-md transition-all cursor-pointer group"
        title="Voice Assistant: Change voice, audition speech, or start live call"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span>Voice Assistant</span>
      </button>

      {/* Sidebar */}
      <Sidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
        onSelectSession={(id) => setCurrentSessionId(id)}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onClearAllSessions={handleClearAllSessions}
        onExportSession={handleExportSession}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-zinc-950 relative">
        {/* Header */}
        <ChatHeader
          isSidebarOpen={isSidebarOpen}
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          selectedModel={selectedModel}
          onSelectModel={handleSelectModel}
          selectedPersona={selectedPersona}
          onSelectPersona={handleSelectPersona}
          groundingMode={groundingMode}
          onSelectGrounding={handleSelectGrounding}
          onNewChat={handleNewChat}
          onOpenVoice={() => setIsVoiceModalOpen(true)}
          onOpenVoicePanel={() => setIsVoicePanelOpen(true)}
          selectedVoice={selectedVoice}
          onOpenImageGen={() => setIsImageModalOpen(true)}
          onOpenScience={() => setIsScienceModalOpen(true)}
          onOpenInfo={() => setIsInfoModalOpen(true)}
          onOpenDocs={() => setIsDocModalOpen(true)}
          onOpenPublish={() => setIsPublishModalOpen(true)}
          user={currentUser}
          onSignIn={handleGoogleSignIn}
          onSignOut={handleGoogleSignOut}
        />

        {/* Message Feed / Welcome Screen */}
        <div className="flex-1 overflow-y-auto flex flex-col relative">
          {messages.length === 0 ? (
            <WelcomeScreen
              onSelectPrompt={(prompt) => handleSendMessage(prompt)}
              selectedPersona={selectedPersona}
            />
          ) : (
            <div className="flex-1 py-4 divide-y divide-zinc-900/60">
              {messages.map((message, index) => {
                const isLastModel =
                  message.role === 'model' && index === messages.length - 1;
                return (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    isLastModelMessage={isLastModel}
                    onRegenerate={handleRegenerate}
                    onEditPrompt={(text) => handleSendMessage(text)}
                    onFeedback={handleFeedback}
                    voiceName={selectedVoice}
                  />
                );
              })}
              <div ref={messagesEndRef} className="h-6" />
            </div>
          )}
        </div>

        {/* Floating Input Dock */}
        <ChatInput
          onSendMessage={handleSendMessage}
          onStopGeneration={handleStopGeneration}
          isGenerating={isGenerating}
        />
      </div>
    </div>
  );
}
