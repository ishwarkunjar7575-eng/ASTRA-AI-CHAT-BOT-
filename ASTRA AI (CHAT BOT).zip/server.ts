import express from 'express';
import type { Request, Response } from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

interface ChatPart {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
}

interface IncomingMessage {
  role: 'user' | 'model';
  parts: ChatPart[];
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);

  app.use(express.json({ limit: '30mb' }));

  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Health check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      hasApiKey: Boolean(apiKey),
      app: 'ASTRA AI',
      timestamp: new Date().toISOString(),
    });
  });

  // 1. Stream chat response with multi-model support & grounding (Search / Maps)
  app.post('/api/chat/stream', async (req: Request, res: Response) => {
    try {
      if (!apiKey) {
        res.status(500).json({
          error: 'GEMINI_API_KEY is not configured on the server. Please verify your environment setup.',
        });
        return;
      }

      const {
        messages = [],
        model = 'gemini-3.8-flash',
        grounding = 'none', // 'none' | 'search' | 'maps'
        systemInstruction = 'You are ASTRA AI, an ultra-capable, friendly, and helpful AI chatbot inspired by next-generation models. You write clear, beautifully formatted answers with markdown, tables, and highlighted code snippets when relevant.',
      } = req.body;

      if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: 'Messages array is required.' });
        return;
      }

      // Valid requested models
      const validModels = [
        'gemini-3.8-flash',
        'gemini-3.5-flash',
        'gemini-3.1-pro-preview',
        'gemini-3.1-flash-lite',
      ];
      let targetModel = validModels.includes(model) ? model : 'gemini-3.8-flash';

      // Format messages for @google/genai
      const formattedContents = messages.map((msg: IncomingMessage) => ({
        role: msg.role === 'model' ? 'model' : 'user',
        parts: msg.parts.map((part) => {
          if (part.inlineData) {
            return {
              inlineData: {
                mimeType: part.inlineData.mimeType,
                data: part.inlineData.data,
              },
            };
          }
          return {
            text: part.text || '',
          };
        }),
      }));

      // Setup Server-Sent Events headers
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
      res.flushHeaders?.();

      let clientDisconnected = false;
      res.on('close', () => {
        if (!res.writableEnded) {
          clientDisconnected = true;
        }
      });

      // Prepare config with tools if grounding is requested
      const config: any = {
        systemInstruction,
      };

      if (grounding === 'search') {
        config.tools = [{ googleSearch: {} }];
        // Grounding with googleSearch works best on gemini-3.5-flash or gemini-3.8-flash
        if (targetModel !== 'gemini-3.5-flash' && targetModel !== 'gemini-3.8-flash') {
          targetModel = 'gemini-3.5-flash';
        }
      } else if (grounding === 'maps') {
        config.tools = [{ googleMaps: {} }];
        if (targetModel !== 'gemini-3.5-flash') {
          targetModel = 'gemini-3.5-flash';
        }
      }

      let responseStream;
      try {
        responseStream = await ai.models.generateContentStream({
          model: targetModel,
          contents: formattedContents,
          config,
        });
      } catch (primaryErr: unknown) {
        console.warn(
          `Primary model ${targetModel} encountered an issue:`,
          primaryErr instanceof Error ? primaryErr.message : primaryErr
        );
        // Fallback without special tools to flash-lite
        try {
          responseStream = await ai.models.generateContentStream({
            model: 'gemini-3.1-flash-lite',
            contents: formattedContents,
            config: {
              systemInstruction,
            },
          });
        } catch (fallbackErr) {
          throw primaryErr;
        }
      }

      for await (const chunk of responseStream) {
        if (clientDisconnected) break;
        const text = chunk.text || '';
        if (text) {
          res.write(`data: ${JSON.stringify({ text })}\n\n`);
        }
      }

      if (!res.writableEnded) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
    } catch (err: unknown) {
      console.error('Error generating chat content:', err);
      const errorMessage =
        err instanceof Error ? err.message : 'An unexpected error occurred while communicating with chatxyz.';

      if (!res.headersSent) {
        res.status(500).json({ error: errorMessage });
      } else {
        res.write(`data: ${JSON.stringify({ error: errorMessage })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
      }
    }
  });

  // 2. Generate title
  app.post('/api/chat/generate-title', async (req: Request, res: Response) => {
    try {
      if (!apiKey) {
        res.json({ title: 'New Conversation' });
        return;
      }

      const { prompt } = req.body;
      if (!prompt || typeof prompt !== 'string') {
        res.json({ title: 'New Conversation' });
        return;
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: `Summarize the user prompt into a concise title of 2 to 5 words for a chat session. No quotes, no periods: "${prompt.slice(0, 300)}"`,
      });

      const title = response.text?.trim().replace(/^["']|["']$/g, '') || 'New Conversation';
      res.json({ title: title.slice(0, 45) });
    } catch (err) {
      console.error('Error generating title:', err);
      res.json({ title: 'New Conversation' });
    }
  });

  // 3. Create & Edit Images using gemini-nano-banana-2.1 with fallback
  app.post('/api/image/generate', async (req: Request, res: Response) => {
    try {
      if (!apiKey) {
        res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
        return;
      }

      const { prompt, base64Image, mimeType = 'image/png', aspectRatio = '1:1' } = req.body;

      if (!prompt) {
        res.status(400).json({ error: 'Prompt is required.' });
        return;
      }

      // If an existing image is provided, edit it; otherwise create new
      const parts: any[] = [];
      if (base64Image) {
        parts.push({
          inlineData: {
            mimeType,
            data: base64Image,
          },
        });
      }
      parts.push({ text: prompt });

      let targetModel = 'gemini-nano-banana-2.1';
      let response;

      try {
        response = await ai.models.generateContent({
          model: targetModel,
          contents: { parts },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
              imageSize: '1K',
            },
          },
        });
      } catch (err) {
        console.warn('gemini-nano-banana-2.1 failed, falling back to gemini-3.1-flash-lite-image:', err);
        targetModel = 'gemini-3.1-flash-lite-image';
        response = await ai.models.generateContent({
          model: targetModel,
          contents: { parts },
        });
      }

      let generatedImageUrl: string | null = null;
      let responseText = '';

      const candidates = response.candidates || [];
      for (const candidate of candidates) {
        const cParts = candidate.content?.parts || [];
        for (const part of cParts) {
          if (part.inlineData) {
            generatedImageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
          } else if (part.text) {
            responseText += part.text;
          }
        }
      }

      if (!generatedImageUrl) {
        res.status(500).json({
          error: 'No image was generated by the model. Try refining your prompt.',
          text: responseText,
        });
        return;
      }

      res.json({
        imageUrl: generatedImageUrl,
        text: responseText,
        model: targetModel,
      });
    } catch (err: unknown) {
      console.error('Error generating image:', err);
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to generate image.',
      });
    }
  });

  // 4. Science Skills: PubChem query proxy
  app.get('/api/science/pubchem', async (req: Request, res: Response) => {
    try {
      const query = String(req.query.query || '').trim();
      if (!query) {
        res.status(400).json({ error: 'Query parameter is required' });
        return;
      }

      // Query PubChem compound by name or CID
      const url = `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${encodeURIComponent(query)}/property/MolecularFormula,MolecularWeight,IUPACName,CanonicalSMILES/JSON`;
      const response = await fetch(url);
      if (!response.ok) {
        res.status(404).json({ error: `Compound '${query}' not found in PubChem.` });
        return;
      }

      const data = await response.json();
      const props = data.PropertyTable?.Properties?.[0];
      if (!props) {
        res.status(404).json({ error: 'No properties found.' });
        return;
      }

      const cid = props.CID;
      res.json({
        cid,
        name: query,
        formula: props.MolecularFormula,
        molecularWeight: props.MolecularWeight,
        iupacName: props.IUPACName,
        smiles: props.CanonicalSMILES,
        structureImageUrl: `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${cid}/PNG`,
        pubchemUrl: `https://pubchem.ncbi.nlm.nih.gov/compound/${cid}`,
      });
    } catch (err) {
      console.error('PubChem proxy error:', err);
      res.status(500).json({ error: 'Error fetching PubChem data' });
    }
  });

  // 5. Science Skills: UniProtKB proxy
  app.get('/api/science/uniprot', async (req: Request, res: Response) => {
    try {
      const query = String(req.query.query || '').trim();
      if (!query) {
        res.status(400).json({ error: 'Query parameter is required' });
        return;
      }

      const url = `https://rest.uniprot.org/uniprotkb/search?query=${encodeURIComponent(query)}&size=5&fields=accession,id,protein_name,gene_names,organism_name,length`;
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (!response.ok) {
        res.status(response.status).json({ error: 'UniProt search failed.' });
        return;
      }

      const data = await response.json();
      res.json(data.results || []);
    } catch (err) {
      console.error('UniProt proxy error:', err);
      res.status(500).json({ error: 'Error querying UniProtKB' });
    }
  });

  // 6. Science Skills: AlphaFold DB prediction metadata
  app.get('/api/science/alphafold', async (req: Request, res: Response) => {
    try {
      const accession = String(req.query.accession || '').trim().toUpperCase();
      if (!accession) {
        res.status(400).json({ error: 'UniProt accession required' });
        return;
      }

      const url = `https://alphafold.ebi.ac.uk/api/prediction/${encodeURIComponent(accession)}`;
      const response = await fetch(url);
      if (!response.ok) {
        res.status(404).json({ error: `AlphaFold structure not found for ${accession}` });
        return;
      }

      const data = await response.json();
      const first = Array.isArray(data) ? data[0] : data;
      res.json(first || {});
    } catch (err) {
      console.error('AlphaFold proxy error:', err);
      res.status(500).json({ error: 'Error fetching AlphaFold structure' });
    }
  });

  // 7. Science Skills: PubMed search proxy
  app.get('/api/science/pubmed', async (req: Request, res: Response) => {
    try {
      const query = String(req.query.query || '').trim();
      if (!query) {
        res.status(400).json({ error: 'Query parameter is required' });
        return;
      }

      // 1. Search for PMIDs
      const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(query)}&retmode=json&retmax=4`;
      const searchRes = await fetch(searchUrl);
      const searchData = await searchRes.json();
      const idList = searchData.esearchresult?.idlist || [];

      if (idList.length === 0) {
        res.json({ articles: [] });
        return;
      }

      // 2. Fetch summaries for PMIDs
      const summaryUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${idList.join(',')}&retmode=json`;
      const summaryRes = await fetch(summaryUrl);
      const summaryData = await summaryRes.json();

      const articles = idList.map((id: string) => {
        const item = summaryData.result?.[id] || {};
        return {
          pmid: id,
          title: item.title || 'Untitled Article',
          authors: item.authors?.map((a: any) => a.name).slice(0, 3).join(', ') || 'Unknown Authors',
          source: item.source || item.fulljournalname || '',
          pubdate: item.pubdate || '',
          url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
        };
      });

      res.json({ articles });
    } catch (err) {
      console.error('PubMed proxy error:', err);
      res.status(500).json({ error: 'Error querying PubMed' });
    }
  });

  // 8. Gemini Neural TTS endpoint (gemini-3.8-flash-lite-tts)
  app.post('/api/voice/speak', async (req: Request, res: Response) => {
    try {
      if (!apiKey) {
        res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
        return;
      }

      const { text, voiceName = 'Zephyr' } = req.body;
      if (!text || typeof text !== 'string') {
        res.status(400).json({ error: 'Text is required.' });
        return;
      }

      // Truncate to first 1200 characters for optimal TTS performance
      const cleanText = text
        .replace(/```[\s\S]*?```/g, ' [code snippet omitted] ')
        .replace(/[#*`_~]/g, '')
        .trim()
        .slice(0, 1200);

      const validVoices = ['Zephyr', 'Kore', 'Puck', 'Fenrir', 'Charon'];
      const targetVoice = validVoices.includes(voiceName) ? voiceName : 'Zephyr';

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: cleanText,
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: targetVoice },
            },
          },
        },
      });

      const base64Audio =
        response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

      if (!base64Audio) {
        res.status(500).json({ error: 'No audio data was generated.' });
        return;
      }

      res.json({
        audio: base64Audio,
        mimeType: 'audio/wav',
        voiceName: targetVoice,
      });
    } catch (err: unknown) {
      console.error('TTS error:', err);
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to generate voice audio.',
      });
    }
  });

  // Documentation endpoints
  app.get('/DOCUMENTATION.md', (_req: Request, res: Response) => {
    res.sendFile(path.resolve(__dirname, 'DOCUMENTATION.md'));
  });

  app.get('/api/docs', (_req: Request, res: Response) => {
    res.sendFile(path.resolve(__dirname, 'DOCUMENTATION.md'));
  });

  // 9. WebSocket server for Gemini 3.8 Live API Voice conversations
  const wss = new WebSocketServer({ server, path: '/api/live' });

  wss.on('connection', async (clientWs: WebSocket, req: http.IncomingMessage) => {
    console.log('[Live API] Client connected to Voice WebSocket');
    let session: any = null;

    // Read voice query param if provided, e.g. /api/live?voice=Kore
    const urlParams = new URL(req.url || '', `http://${req.headers.host}`).searchParams;
    const requestedVoice = urlParams.get('voice') || 'Zephyr';
    const validVoices = ['Zephyr', 'Kore', 'Puck', 'Fenrir', 'Charon'];
    const chosenVoice = validVoices.includes(requestedVoice) ? requestedVoice : 'Zephyr';

    try {
      session = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: chosenVoice },
            },
          },
          systemInstruction:
            'You are ASTRA AI Voice Assistant, an ultra-smart, engaging, and friendly real-time conversational companion. Keep your spoken responses natural, expressive, concise, and lively.',
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ audio }));
            }
            if (message.serverContent?.interrupted && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ interrupted: true }));
            }
          },
          onclose: () => {
            console.log('[Live API] Session closed by Gemini');
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ closed: true }));
            }
          },
        },
      });

      clientWs.on('message', (data: Buffer | string) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (parsed.audio && session) {
            session.sendRealtimeInput({
              audio: {
                data: parsed.audio,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          } else if (parsed.text && session) {
            session.sendRealtimeInput({
              text: parsed.text,
            });
          }
        } catch (e) {
          console.error('[Live API] Message parsing error:', e);
        }
      });

      clientWs.on('close', () => {
        console.log('[Live API] Client WebSocket closed');
        try {
          session?.close?.();
        } catch (e) {
          // ignore
        }
      });
    } catch (liveErr) {
      console.error('[Live API] Connection error:', liveErr);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            error:
              liveErr instanceof Error
                ? liveErr.message
                : 'Unable to connect to Gemini 3.8 Live API.',
          })
        );
      }
    }
  });

  // Integrate Vite for development or express.static for production
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[ASTRA AI] Full-stack Server running at http://localhost:${PORT}`);
  });
}

startServer();
